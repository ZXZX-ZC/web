'use strict';

module.exports = require('functions-have-names')();

// TODO: semver-major, remove
