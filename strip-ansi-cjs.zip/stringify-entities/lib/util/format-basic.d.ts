/**
 * The smallest way to encode a character.
 *
 * @param {number} code
 * @returns {string}
 */
export function formatBasic(code: number): string;
