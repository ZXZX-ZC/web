declare const x: typeof Reflect.setPrototypeOf | null;

export = x;