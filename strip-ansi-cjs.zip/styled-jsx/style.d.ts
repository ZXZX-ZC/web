declare module 'styled-jsx/style' {
  export default function JSXStyle(props: any): null
}
