'use client'

import { cn } from '@/lib/utils'

const Spinner = ({ className, size = 'md' }) => {
  const sizeClasses = {
    sm: 'w-4 h-4',
    md: 'w-6 h-6',
    lg: 'w-8 h-8',
    xl: 'w-12 h-12'
  }

  return (
    <svg
      className={cn(
        'animate-spin text-current',
        sizeClasses[size],
        className
      )}
      viewBox="0 0 24 24"
    >
      <circle
        className="opacity-25"
        cx="12"
        cy="12"
        r="10"
        stroke="currentColor"
        strokeWidth="4"
        fill="none"
      />
      <path
        className="opacity-75"
        fill="currentColor"
        d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
      />
    </svg>
  )
}

const Loading = ({ 
  className, 
  text = '加载中...', 
  size = 'md',
  variant = 'default' 
}) => {
  const variants = {
    default: 'text-gray-600',
    primary: 'text-primary-600',
    white: 'text-white'
  }

  return (
    <div className={cn('flex items-center justify-center gap-3', className)}>
      <Spinner size={size} className={variants[variant]} />
      {text && (
        <span className={cn('text-sm font-medium', variants[variant])}>
          {text}
        </span>
      )}
    </div>
  )
}

const LoadingOverlay = ({ 
  show = false, 
  text = '加载中...', 
  className 
}) => {
  if (!show) return null

  return (
    <div className={cn(
      'absolute inset-0 bg-white/80 backdrop-blur-sm flex items-center justify-center z-50',
      className
    )}>
      <Loading text={text} size="lg" />
    </div>
  )
}

const LoadingPage = ({ text = '页面加载中...' }) => {
  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="text-center">
        <Loading text={text} size="xl" />
        <p className="mt-4 text-gray-500 text-sm">
          请稍候，内容正在准备中...
        </p>
      </div>
    </div>
  )
}

const LoadingButton = ({ 
  loading = false, 
  children, 
  disabled,
  className,
  ...props 
}) => {
  return (
    <button
      className={cn(
        'inline-flex items-center justify-center gap-2',
        'px-4 py-2 bg-primary-600 text-white rounded-lg',
        'hover:bg-primary-700 disabled:opacity-50 disabled:cursor-not-allowed',
        'transition-colors duration-200',
        className
      )}
      disabled={disabled || loading}
      {...props}
    >
      {loading && <Spinner size="sm" className="text-current" />}
      {children}
    </button>
  )
}

const LoadingSkeleton = ({ 
  lines = 3, 
  className,
  variant = 'text' 
}) => {
  const variants = {
    text: 'h-4',
    title: 'h-6',
    button: 'h-10 w-24',
    avatar: 'h-12 w-12 rounded-full',
    card: 'h-32'
  }

  if (variant !== 'text') {
    return (
      <div 
        className={cn(
          'bg-gray-200 animate-pulse rounded',
          variants[variant],
          className
        )}
      />
    )
  }

  return (
    <div className={cn('space-y-3', className)}>
      {Array.from({ length: lines }, (_, i) => (
        <div
          key={i}
          className={cn(
            'bg-gray-200 animate-pulse rounded',
            variants[variant],
            i === lines - 1 && 'w-3/4' // 最后一行稍短
          )}
        />
      ))}
    </div>
  )
}

const LoadingCard = ({ className }) => {
  return (
    <div className={cn('bg-white rounded-lg shadow-sm border border-gray-200 p-6', className)}>
      <div className="flex items-center space-x-4 mb-4">
        <LoadingSkeleton variant="avatar" />
        <div className="flex-1">
          <LoadingSkeleton variant="title" className="mb-2" />
          <LoadingSkeleton lines={1} />
        </div>
      </div>
      <LoadingSkeleton lines={3} className="mb-4" />
      <div className="flex space-x-2">
        <LoadingSkeleton variant="button" />
        <LoadingSkeleton variant="button" />
      </div>
    </div>
  )
}

const LoadingDots = ({ className }) => {
  return (
    <div className={cn('flex space-x-1', className)}>
      {[0, 1, 2].map((i) => (
        <div
          key={i}
          className="w-2 h-2 bg-current rounded-full animate-pulse"
          style={{
            animationDelay: `${i * 0.2}s`,
            animationDuration: '1s'
          }}
        />
      ))}
    </div>
  )
}

const PulsingDot = ({ className }) => {
  return (
    <div className={cn('flex items-center space-x-2', className)}>
      <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
      <span className="text-sm text-gray-600">实时更新中</span>
    </div>
  )
}

export {
  Spinner,
  Loading,
  LoadingOverlay,
  LoadingPage,
  LoadingButton,
  LoadingSkeleton,
  LoadingCard,
  LoadingDots,
  PulsingDot
}

export default Loading