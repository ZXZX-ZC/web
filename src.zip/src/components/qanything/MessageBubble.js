'use client'

import { User, Bot, Copy, Check, ExternalLink } from 'lucide-react'
import { useState } from 'react'

export default function MessageBubble({ message }) {
  const [copied, setCopied] = useState(false)
  const isBot = message.type === 'bot'
  const isUser = message.type === 'user'

  // 复制消息内容
  const copyToClipboard = async (text) => {
    try {
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch (err) {
      console.error('Failed to copy text:', err)
    }
  }

  // 格式化时间
  const formatTime = (timestamp) => {
    const date = new Date(timestamp)
    return date.toLocaleTimeString('zh-CN', { 
      hour: '2-digit', 
      minute: '2-digit' 
    })
  }

  // 渲染消息内容，支持简单的Markdown样式
  const renderContent = (content) => {
    // 简单的文本格式化
    const lines = content.split('\n')
    return lines.map((line, index) => {
      // 检查是否是代码块
      if (line.startsWith('```')) {
        return <div key={index} className="font-mono text-sm bg-gray-100 px-2 py-1 rounded mt-1">{line.replace(/```/g, '')}</div>
      }
      // 检查是否是行内代码
      if (line.includes('`')) {
        const parts = line.split('`')
        return (
          <div key={index}>
            {parts.map((part, i) => 
              i % 2 === 0 ? part : <code key={i} className="bg-gray-100 px-1 rounded text-sm">{part}</code>
            )}
          </div>
        )
      }
      // 普通文本
      return line ? <div key={index}>{line}</div> : <br key={index} />
    })
  }

  return (
    <div className={`flex gap-3 ${isUser ? 'justify-end' : 'justify-start'}`}>
      {/* 头像 */}
      {isBot && (
        <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0">
          <Bot className="w-4 h-4 text-purple-600" />
        </div>
      )}

      {/* 消息内容 */}
      <div className={`max-w-[70%] ${isUser ? 'order-first' : ''}`}>
        <div
          className={`rounded-lg px-4 py-2 ${
            isUser
              ? 'bg-purple-600 text-white'
              : message.isError
              ? 'bg-red-50 border border-red-200 text-red-700'
              : 'bg-gray-100 text-gray-900'
          }`}
        >
          <div className="whitespace-pre-wrap break-words">
            {renderContent(message.content)}
          </div>

          {/* 来源信息 */}
          {message.sources && message.sources.length > 0 && (
            <div className="mt-3 pt-3 border-t border-gray-200">
              <p className="text-xs text-gray-600 mb-2">参考来源:</p>
              <div className="space-y-1">
                {message.sources.map((source, index) => (
                  <a
                    key={index}
                    href={source.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-1 text-xs text-blue-600 hover:text-blue-800"
                  >
                    <ExternalLink className="w-3 h-3" />
                    {source.title || source.url}
                  </a>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* 消息元信息 */}
        <div className={`flex items-center gap-2 mt-1 ${isUser ? 'justify-end' : 'justify-start'}`}>
          <span className="text-xs text-gray-500">
            {formatTime(message.timestamp)}
          </span>
          
          {/* API状态信息 */}
          {isBot && (
            <>
              {message._isRealAPI && (
                <span className="text-xs text-green-600 bg-green-50 px-2 py-0.5 rounded">
                  真实API
                </span>
              )}
              {message._isMockData && (
                <span className="text-xs text-blue-600 bg-blue-50 px-2 py-0.5 rounded">
                  演示模式
                </span>
              )}
              {message._fallbackReason && (
                <span className="text-xs text-orange-600 bg-orange-50 px-2 py-0.5 rounded" title={message._fallbackReason}>
                  降级回复
                </span>
              )}
              {message.model && (
                <span className="text-xs text-gray-400">
                  {message.model}
                </span>
              )}
            </>
          )}

          {/* 复制按钮 */}
          <button
            onClick={() => copyToClipboard(message.content)}
            className="text-gray-400 hover:text-gray-600 p-1 rounded"
            title="复制消息"
          >
            {copied ? (
              <Check className="w-3 h-3 text-green-500" />
            ) : (
              <Copy className="w-3 h-3" />
            )}
          </button>
        </div>
      </div>

      {/* 用户头像 */}
      {isUser && (
        <div className="w-8 h-8 bg-purple-600 rounded-full flex items-center justify-center flex-shrink-0">
          <User className="w-4 h-4 text-white" />
        </div>
      )}
    </div>
  )
}