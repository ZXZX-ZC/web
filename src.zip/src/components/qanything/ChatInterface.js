'use client'

import { useState, useRef, useEffect } from 'react'
import { Send, Trash2, User, Bot, Loader2 } from 'lucide-react'
import MessageBubble from './MessageBubble'

export default function ChatInterface() {
  const [messages, setMessages] = useState([
    {
      id: 1,
      type: 'bot',
      content: '您好！我是QAnything AI助手，很高兴为您服务。有什么可以帮助您的吗？',
      timestamp: new Date().toISOString()
    }
  ])
  const [inputValue, setInputValue] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [conversationId, setConversationId] = useState(null)
  const [error, setError] = useState(null)
  
  const messagesEndRef = useRef(null)
  const inputRef = useRef(null)

  // 自动滚动到最新消息
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  // 发送消息
  const handleSendMessage = async () => {
    const trimmedInput = inputValue.trim()
    if (!trimmedInput || isLoading) return

    const userMessage = {
      id: Date.now(),
      type: 'user',
      content: trimmedInput,
      timestamp: new Date().toISOString()
    }

    // 添加用户消息
    setMessages(prev => [...prev, userMessage])
    setInputValue('')
    setIsLoading(true)
    setError(null)

    try {
      console.log('Sending message to API:', trimmedInput.substring(0, 50) + '...')
      
      const response = await fetch('/api/qanything', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message: trimmedInput,
          conversation_id: conversationId
        }),
      })

      console.log('API response status:', response.status)

      if (!response.ok) {
        let errorMessage = `HTTP ${response.status}: ${response.statusText}`
        
        try {
          const errorData = await response.json()
          errorMessage = errorData.error || errorMessage
        } catch (e) {
          // 忽略JSON解析错误，使用默认错误消息
        }
        
        throw new Error(errorMessage)
      }

      const data = await response.json()
      console.log('API response data:', {
        hasMessage: !!data.message,
        messageLength: data.message?.length,
        isRealAPI: data._isRealAPI,
        isMockData: data._isMockData,
        fallbackReason: data._fallbackReason
      })

      // 更新对话ID
      if (data.conversation_id && !conversationId) {
        setConversationId(data.conversation_id)
      }

      // 添加AI回复
      const botMessage = {
        id: Date.now() + 1,
        type: 'bot',
        content: data.message || '抱歉，我没有收到有效的回复。',
        timestamp: data.timestamp || new Date().toISOString(),
        sources: data.sources || [],
        model: data.model,
        _isMockData: data._isMockData,
        _isRealAPI: data._isRealAPI,
        _fallbackReason: data._fallbackReason,
        _isError: data._isError
      }

      setMessages(prev => [...prev, botMessage])

      // 如果是降级回复，显示提示
      if (data._fallbackReason) {
        console.log('Using fallback response:', data._fallbackReason)
      }

    } catch (error) {
      console.error('Chat error:', error)
      setError(error.message)
      
      // 添加错误消息
      const errorMessage = {
        id: Date.now() + 1,
        type: 'bot',
        content: `抱歉，发生了错误：${error.message}。请检查网络连接或稍后重试。`,
        timestamp: new Date().toISOString(),
        isError: true
      }
      
      setMessages(prev => [...prev, errorMessage])
    } finally {
      setIsLoading(false)
    }
  }

  // 清空对话
  const clearConversation = () => {
    setMessages([
      {
        id: 1,
        type: 'bot',
        content: '对话已清空，我们可以开始新的对话了。有什么可以帮助您的吗？',
        timestamp: new Date().toISOString()
      }
    ])
    setConversationId(null)
    setError(null)
    inputRef.current?.focus()
  }

  // 处理键盘事件
  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  // 示例问题
  const exampleQuestions = [
    "请介绍一下React的核心概念",
    "如何学习前端开发？",
    "JavaScript中的闭包是什么？",
    "Next.js相比React有什么优势？",
    "如何构建个人作品集项目？",
    "WakaTime编码统计有什么用？",
    "AI在编程中的应用场景",
    "前端技术栈该如何选择？"
  ]

  const handleExampleClick = (question) => {
    setInputValue(question)
    inputRef.current?.focus()
  }

  return (
    <div className="flex flex-col h-[600px]">
      {/* 消息列表 */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message) => (
          <MessageBubble 
            key={message.id} 
            message={message} 
          />
        ))}
        
        {/* 加载状态 */}
        {isLoading && (
          <div className="flex items-center gap-2 text-gray-500">
            <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center">
              <Bot className="w-4 h-4" />
            </div>
            <div className="bg-gray-100 rounded-lg px-4 py-2">
              <div className="flex items-center gap-2">
                <Loader2 className="w-4 h-4 animate-spin" />
                <span className="text-sm">AI正在思考中...</span>
              </div>
            </div>
          </div>
        )}
        
        {/* 错误提示 */}
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-3">
            <p className="text-red-700 text-sm">
              ❌ 发生错误: {error}
            </p>
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>

      {/* 示例问题 */}
      {messages.length <= 1 && (
        <div className="border-t border-gray-200 p-4">
          <p className="text-sm text-gray-600 mb-3">💡 您可以尝试问这些问题：</p>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2">
            {exampleQuestions.map((question, index) => (
              <button
                key={index}
                onClick={() => handleExampleClick(question)}
                className="text-left text-sm text-blue-600 bg-blue-50 hover:bg-blue-100 rounded-lg p-2 transition-colors"
              >
                {question}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* 输入区域 */}
      <div className="border-t border-gray-200 p-4">
        <div className="flex items-end gap-2">
          <div className="flex-1">
            <textarea
              ref={inputRef}
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="输入您的问题..."
              className="w-full px-4 py-2 border border-gray-300 rounded-lg resize-none focus:ring-2 focus:ring-purple-500 focus:border-purple-500 outline-none transition-colors"
              rows={1}
              style={{
                minHeight: '42px',
                maxHeight: '120px',
                height: 'auto'
              }}
              onInput={(e) => {
                e.target.style.height = 'auto'
                e.target.style.height = e.target.scrollHeight + 'px'
              }}
              disabled={isLoading}
            />
          </div>
          
          <button
            onClick={handleSendMessage}
            disabled={!inputValue.trim() || isLoading}
            className="bg-purple-600 hover:bg-purple-700 disabled:bg-gray-300 text-white p-2 rounded-lg transition-colors"
            title="发送消息 (Enter)"
          >
            {isLoading ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <Send className="w-5 h-5" />
            )}
          </button>
          
          {messages.length > 1 && (
            <button
              onClick={clearConversation}
              className="bg-gray-500 hover:bg-gray-600 text-white p-2 rounded-lg transition-colors"
              title="清空对话"
            >
              <Trash2 className="w-5 h-5" />
            </button>
          )}
        </div>
        
        <div className="flex justify-between items-center mt-2 text-xs text-gray-500">
          <span>按 Enter 发送，Shift + Enter 换行</span>
          {conversationId && (
            <span>对话ID: {conversationId.slice(-8)}</span>
          )}
        </div>
      </div>
    </div>
  )
}