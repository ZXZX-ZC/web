import { User, Code2, Target, Lightbulb, Github, Mail, Calendar } from 'lucide-react'

export const metadata = {
  title: '关于项目 - Course Portfolio',
  description: '了解Course Portfolio项目的设计理念、技术架构和开发历程',
}

const projectFeatures = [
  {
    icon: Code2,
    title: '技术栈展示',
    description: '全面展示HTML/CSS、JavaScript、React、Next.js等现代Web开发技术栈的学习成果'
  },
  {
    icon: Target,
    title: 'API集成',
    description: '集成WakaTime编码统计API和QAnything大语言模型API，展示外部服务调用能力'
  },
  {
    icon: Lightbulb,
    title: '最佳实践',
    description: '遵循现代Web开发最佳实践，包括响应式设计、组件化开发、性能优化等'
  }
]

const technologies = [
  { name: 'Next.js 14', category: '全栈框架', description: 'React全栈开发框架，支持SSR和API路由' },
  { name: 'React 18', category: '前端框架', description: '现代组件化前端框架，支持Hooks和并发特性' },
  { name: 'Tailwind CSS', category: '样式框架', description: '实用优先的CSS框架，快速构建现代UI' },
  { name: 'JavaScript ES6+', category: '编程语言', description: '现代JavaScript语法和特性' },
  { name: 'WakaTime API', category: '外部服务', description: '编码时长统计和分析服务' },
  { name: 'QAnything API', category: 'AI服务', description: '大语言模型问答和对话服务' }
]

const timeline = [
  {
    period: '第1-4周',
    title: 'HTML & CSS 基础',
    description: '学习网页结构设计、样式美化和响应式布局技术',
    achievements: ['掌握HTML5语义化标签', '学会CSS Flexbox和Grid布局', '实现响应式设计']
  },
  {
    period: '第5-8周',
    title: 'JavaScript 交互',
    description: '学习JavaScript核心语法、DOM操作和事件处理',
    achievements: ['掌握ES6+现代语法', '熟练操作DOM元素', '实现复杂交互功能']
  },
  {
    period: '第9-12周',
    title: 'React 组件化',
    description: '学习React框架、组件设计和状态管理',
    achievements: ['理解组件化思维', '掌握React Hooks', '实现状态管理']
  },
  {
    period: '第13-16周',
    title: 'Next.js 整合',
    description: '使用Next.js整合所有学习成果，构建完整应用',
    achievements: ['集成外部API服务', '实现全栈应用', '部署生产环境']
  }
]

export default function AboutPage() {
  return (
    <div className="max-w-6xl mx-auto">
      {/* Header */}
      <div className="text-center mb-12">
        <div className="w-20 h-20 bg-gradient-to-r from-primary-600 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-6">
          <User className="w-10 h-10 text-white" />
        </div>
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          关于 Course Portfolio
        </h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          这是一个综合性的课程作品集项目，展示了从前端基础到现代框架开发的完整学习历程，
          集成多项先进技术和服务，体现了现代Web开发的最佳实践。
        </p>
      </div>

      {/* Project Overview */}
      <div className="card mb-12">
        <div className="card-header">
          <h2 className="text-2xl font-semibold">项目概述</h2>
        </div>
        <div className="card-body">
          <div className="grid md:grid-cols-3 gap-8">
            {projectFeatures.map((feature, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <feature.icon className="w-8 h-8 text-primary-600" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  {feature.title}
                </h3>
                <p className="text-gray-600 text-sm">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Technology Stack */}
      <div className="card mb-12">
        <div className="card-header">
          <h2 className="text-2xl font-semibold">技术架构</h2>
        </div>
        <div className="card-body">
          <div className="grid md:grid-cols-2 gap-6">
            {technologies.map((tech, index) => (
              <div key={index} className="flex items-start gap-4 p-4 bg-gray-50 rounded-lg">
                <div className="w-10 h-10 bg-primary-600 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Code2 className="w-5 h-5 text-white" />
                </div>
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-semibold text-gray-900">{tech.name}</h3>
                    <span className="bg-primary-100 text-primary-700 px-2 py-0.5 rounded text-xs font-medium">
                      {tech.category}
                    </span>
                  </div>
                  <p className="text-gray-600 text-sm">{tech.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Learning Timeline */}
      <div className="card mb-12">
        <div className="card-header">
          <h2 className="text-2xl font-semibold flex items-center gap-2">
            <Calendar className="w-6 h-6 text-primary-600" />
            学习时间线
          </h2>
        </div>
        <div className="card-body">
          <div className="space-y-8">
            {timeline.map((phase, index) => (
              <div key={index} className="flex gap-6">
                <div className="flex flex-col items-center">
                  <div className="w-12 h-12 bg-primary-600 rounded-full flex items-center justify-center text-white font-bold">
                    {index + 1}
                  </div>
                  {index < timeline.length - 1 && (
                    <div className="w-0.5 h-16 bg-primary-200 mt-4"></div>
                  )}
                </div>
                <div className="flex-1 pb-8">
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="text-lg font-semibold text-gray-900">
                      {phase.title}
                    </h3>
                    <span className="bg-primary-100 text-primary-700 px-2 py-1 rounded text-sm font-medium">
                      {phase.period}
                    </span>
                  </div>
                  <p className="text-gray-600 mb-3">{phase.description}</p>
                  <div className="flex flex-wrap gap-2">
                    {phase.achievements.map((achievement, i) => (
                      <span key={i} className="bg-green-100 text-green-700 px-2 py-1 rounded text-sm">
                        ✓ {achievement}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Project Stats */}
      <div className="card mb-12">
        <div className="card-header">
          <h2 className="text-2xl font-semibold">项目统计</h2>
        </div>
        <div className="card-body">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-primary-600 mb-2">16</div>
              <div className="text-sm text-gray-600">学习周数</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-green-600 mb-2">9+</div>
              <div className="text-sm text-gray-600">完成练习</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-600 mb-2">2</div>
              <div className="text-sm text-gray-600">API集成</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-orange-600 mb-2">100%</div>
              <div className="text-sm text-gray-600">响应式设计</div>
            </div>
          </div>
        </div>
      </div>

      {/* Design Philosophy */}
      <div className="card mb-12 bg-gradient-to-r from-blue-50 to-purple-50">
        <div className="card-body">
          <h2 className="text-2xl font-semibold text-gray-900 mb-6">设计理念</h2>
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-3">用户体验优先</h3>
              <p className="text-gray-600 mb-4">
                注重用户界面的直观性和易用性，采用现代设计语言，
                确保在不同设备上都能提供优秀的用户体验。
              </p>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• 响应式设计适配多种设备</li>
                <li>• 直观的导航和信息架构</li>
                <li>• 优雅的动画和交互反馈</li>
                <li>• 无障碍访问支持</li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-3">技术excellence</h3>
              <p className="text-gray-600 mb-4">
                采用现代Web开发最佳实践，注重代码质量、性能优化和可维护性，
                展示专业的开发水准。
              </p>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• 组件化和模块化开发</li>
                <li>• TypeScript增强类型安全</li>
                <li>• 性能优化和懒加载</li>
                <li>• 完整的错误处理机制</li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* Contact & Links */}
      <div className="grid md:grid-cols-2 gap-6">
        <div className="card">
          <div className="card-header">
            <h3 className="text-xl font-semibold">项目链接</h3>
          </div>
          <div className="card-body">
            <div className="space-y-3">
              <a
                href="https://github.com/yourusername/course-portfolio"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
              >
                <Github className="w-5 h-5 text-gray-700" />
                <div>
                  <div className="font-medium text-gray-900">GitHub 仓库</div>
                  <div className="text-sm text-gray-600">查看完整源码</div>
                </div>
              </a>
              <a
                href="https://course-portfolio.vercel.app"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
              >
                <Code2 className="w-5 h-5 text-gray-700" />
                <div>
                  <div className="font-medium text-gray-900">在线演示</div>
                  <div className="text-sm text-gray-600">访问部署版本</div>
                </div>
              </a>
            </div>
          </div>
        </div>

        <div className="card">
          <div className="card-header">
            <h3 className="text-xl font-semibold">联系方式</h3>
          </div>
          <div className="card-body">
            <div className="space-y-3">
              <div className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-gray-700" />
                <div>
                  <div className="font-medium text-gray-900">邮箱</div>
                  <div className="text-sm text-gray-600">your.email@example.com</div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Github className="w-5 h-5 text-gray-700" />
                <div>
                  <div className="font-medium text-gray-900">GitHub</div>
                  <div className="text-sm text-gray-600">@yourusername</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Acknowledgments */}
      <div className="mt-12 card bg-gradient-to-r from-gray-50 to-gray-100">
        <div className="card-body text-center">
          <h3 className="text-xl font-semibold text-gray-900 mb-4">致谢</h3>
          <p className="text-gray-600 max-w-3xl mx-auto">
            感谢课程老师的悉心指导，感谢开源社区提供的优秀工具和框架，
            感谢WakaTime和QAnything等服务提供的API支持。
            这个项目不仅是学习成果的展示，更是对知识分享和开源精神的致敬。
          </p>
        </div>
      </div>
    </div>
  )
}