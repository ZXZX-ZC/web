'use client'

import { useState, useCallback, useEffect } from 'react'
import Link from 'next/link'
import { ArrowLeft, RotateCcw, Github, Code } from 'lucide-react'

export default function CalculatorExercise() {
  const [display, setDisplay] = useState('0')
  const [previousValue, setPreviousValue] = useState(null)
  const [operation, setOperation] = useState(null)
  const [waitingForNewValue, setWaitingForNewValue] = useState(false)
  const [history, setHistory] = useState([])

  // 处理数字输入
  const handleNumber = useCallback((num) => {
    if (waitingForNewValue) {
      setDisplay(String(num))
      setWaitingForNewValue(false)
    } else {
      setDisplay(display === '0' ? String(num) : display + num)
    }
  }, [display, waitingForNewValue])

  // 处理小数点
  const handleDecimal = useCallback(() => {
    if (waitingForNewValue) {
      setDisplay('0.')
      setWaitingForNewValue(false)
    } else if (display.indexOf('.') === -1) {
      setDisplay(display + '.')
    }
  }, [display, waitingForNewValue])

  // 处理运算符
  const handleOperation = useCallback((nextOperation) => {
    const inputValue = parseFloat(display)

    if (previousValue === null) {
      setPreviousValue(inputValue)
    } else if (operation) {
      const currentValue = previousValue || 0
      const newValue = performCalculation(currentValue, inputValue, operation)

      setDisplay(String(newValue))
      setPreviousValue(newValue)
      
      // 添加到历史记录
      setHistory(prev => [...prev, `${currentValue} ${operation} ${inputValue} = ${newValue}`])
    }

    setWaitingForNewValue(true)
    setOperation(nextOperation)
  }, [display, previousValue, operation])

  // 执行计算
  const performCalculation = (firstValue, secondValue, operation) => {
    switch (operation) {
      case '+':
        return firstValue + secondValue
      case '-':
        return firstValue - secondValue
      case '×':
        return firstValue * secondValue
      case '÷':
        return secondValue !== 0 ? firstValue / secondValue : 0
      case '%':
        return firstValue % secondValue
      default:
        return secondValue
    }
  }

  // 处理等号
  const handleEquals = useCallback(() => {
    const inputValue = parseFloat(display)

    if (previousValue !== null && operation) {
      const newValue = performCalculation(previousValue, inputValue, operation)
      
      // 添加到历史记录
      setHistory(prev => [...prev, `${previousValue} ${operation} ${inputValue} = ${newValue}`])
      
      setDisplay(String(newValue))
      setPreviousValue(null)
      setOperation(null)
      setWaitingForNewValue(true)
    }
  }, [display, previousValue, operation])

  // 清空
  const handleClear = useCallback(() => {
    setDisplay('0')
    setPreviousValue(null)
    setOperation(null)
    setWaitingForNewValue(false)
  }, [])

  // 清空历史记录
  const clearHistory = useCallback(() => {
    setHistory([])
  }, [])

  // 键盘事件处理
  useEffect(() => {
    const handleKeyPress = (event) => {
      const { key } = event
      
      if (key >= '0' && key <= '9') {
        handleNumber(parseInt(key))
      } else if (key === '.') {
        handleDecimal()
      } else if (key === '+') {
        handleOperation('+')
      } else if (key === '-') {
        handleOperation('-')
      } else if (key === '*') {
        handleOperation('×')
      } else if (key === '/') {
        event.preventDefault()
        handleOperation('÷')
      } else if (key === '%') {
        handleOperation('%')
      } else if (key === 'Enter' || key === '=') {
        event.preventDefault()
        handleEquals()
      } else if (key === 'Escape' || key === 'c' || key === 'C') {
        handleClear()
      }
    }

    window.addEventListener('keydown', handleKeyPress)
    return () => window.removeEventListener('keydown', handleKeyPress)
  }, [handleNumber, handleDecimal, handleOperation, handleEquals, handleClear])

  const buttonClass = "w-full h-14 rounded-lg font-semibold text-lg transition-all duration-200 active:scale-95"
  const numberButtonClass = `${buttonClass} bg-gray-100 hover:bg-gray-200 text-gray-900`
  const operatorButtonClass = `${buttonClass} bg-orange-500 hover:bg-orange-600 text-white`
  const specialButtonClass = `${buttonClass} bg-gray-300 hover:bg-gray-400 text-gray-900`

  return (
    <div className="max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex items-center gap-4 mb-8">
        <Link 
          href="/exercises/javascript"
          className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
        </Link>
        <div>
          <h1 className="text-3xl font-bold text-gray-900">交互式计算器</h1>
          <p className="text-gray-600 mt-1">
            JavaScript DOM操作和事件处理练习 - 支持键盘快捷键
          </p>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Calculator */}
        <div className="lg:col-span-2">
          <div className="card overflow-hidden">
            <div className="card-header">
              <h2 className="text-xl font-semibold flex items-center gap-2">
                <Code className="w-5 h-5 text-orange-600" />
                计算器演示
              </h2>
              <p className="text-sm text-gray-600 mt-1">
                支持基本四则运算，可使用键盘操作 (ESC清空，Enter计算)
              </p>
            </div>
            
            <div className="p-6">
              {/* 显示屏 */}
              <div className="mb-6">
                <div className="bg-gray-900 text-white p-6 rounded-lg">
                  <div className="text-right">
                    {/* 操作显示 */}
                    {previousValue !== null && operation && (
                      <div className="text-gray-400 text-lg mb-1">
                        {previousValue} {operation}
                      </div>
                    )}
                    {/* 主显示 */}
                    <div className="text-4xl font-mono font-bold overflow-hidden">
                      {display}
                    </div>
                  </div>
                </div>
              </div>

              {/* 按键面板 */}
              <div className="grid grid-cols-4 gap-3">
                {/* 第一行 */}
                <button onClick={handleClear} className={specialButtonClass}>
                  AC
                </button>
                <button onClick={() => handleOperation('%')} className={specialButtonClass}>
                  %
                </button>
                <button 
                  onClick={() => setDisplay(String(-parseFloat(display)))} 
                  className={specialButtonClass}
                >
                  ±
                </button>
                <button onClick={() => handleOperation('÷')} className={operatorButtonClass}>
                  ÷
                </button>

                {/* 第二行 */}
                <button onClick={() => handleNumber(7)} className={numberButtonClass}>
                  7
                </button>
                <button onClick={() => handleNumber(8)} className={numberButtonClass}>
                  8
                </button>
                <button onClick={() => handleNumber(9)} className={numberButtonClass}>
                  9
                </button>
                <button onClick={() => handleOperation('×')} className={operatorButtonClass}>
                  ×
                </button>

                {/* 第三行 */}
                <button onClick={() => handleNumber(4)} className={numberButtonClass}>
                  4
                </button>
                <button onClick={() => handleNumber(5)} className={numberButtonClass}>
                  5
                </button>
                <button onClick={() => handleNumber(6)} className={numberButtonClass}>
                  6
                </button>
                <button onClick={() => handleOperation('-')} className={operatorButtonClass}>
                  -
                </button>

                {/* 第四行 */}
                <button onClick={() => handleNumber(1)} className={numberButtonClass}>
                  1
                </button>
                <button onClick={() => handleNumber(2)} className={numberButtonClass}>
                  2
                </button>
                <button onClick={() => handleNumber(3)} className={numberButtonClass}>
                  3
                </button>
                <button onClick={() => handleOperation('+')} className={operatorButtonClass}>
                  +
                </button>

                {/* 第五行 */}
                <button onClick={() => handleNumber(0)} className={`${numberButtonClass} col-span-2`}>
                  0
                </button>
                <button onClick={handleDecimal} className={numberButtonClass}>
                  .
                </button>
                <button onClick={handleEquals} className={operatorButtonClass}>
                  =
                </button>
              </div>

              {/* 键盘快捷键提示 */}
              <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                <h4 className="font-semibold text-blue-900 mb-2">键盘快捷键</h4>
                <div className="grid grid-cols-2 gap-2 text-sm text-blue-700">
                  <div>• 数字键: 0-9</div>
                  <div>• 运算符: +, -, *, /</div>
                  <div>• 小数点: .</div>
                  <div>• 计算: Enter 或 =</div>
                  <div>• 清空: ESC 或 C</div>
                  <div>• 百分比: %</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* 历史记录和代码说明 */}
        <div className="space-y-6">
          {/* 历史记录 */}
          <div className="card">
            <div className="card-header flex justify-between items-center">
              <h3 className="font-semibold">计算历史</h3>
              <button 
                onClick={clearHistory}
                className="text-gray-500 hover:text-gray-700 p-1"
                title="清空历史"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>
            <div className="card-body">
              {history.length > 0 ? (
                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {history.slice(-10).reverse().map((record, index) => (
                    <div key={index} className="text-sm font-mono bg-gray-50 p-2 rounded">
                      {record}
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-gray-500 text-sm text-center py-4">
                  暂无计算记录
                </p>
              )}
            </div>
          </div>

          {/* 技术要点 */}
          <div className="card">
            <div className="card-header">
              <h3 className="font-semibold">技术要点</h3>
            </div>
            <div className="card-body">
              <div className="space-y-4 text-sm">
                <div>
                  <h4 className="font-medium text-gray-900 mb-1">React Hooks</h4>
                  <p className="text-gray-600">使用useState管理状态，useCallback优化性能，useEffect处理副作用</p>
                </div>
                <div>
                  <h4 className="font-medium text-gray-900 mb-1">事件处理</h4>
                  <p className="text-gray-600">实现键盘事件监听，支持快捷键操作和按钮点击</p>
                </div>
                <div>
                  <h4 className="font-medium text-gray-900 mb-1">状态管理</h4>
                  <p className="text-gray-600">合理设计状态结构，处理复杂的计算逻辑和用户交互</p>
                </div>
                <div>
                  <h4 className="font-medium text-gray-900 mb-1">用户体验</h4>
                  <p className="text-gray-600">添加视觉反馈、历史记录和错误处理，提升交互体验</p>
                </div>
              </div>
            </div>
          </div>

          {/* 源码链接 */}
          <div className="card">
            <div className="card-body text-center">
              <a
                href="https://github.com/yourusername/course-portfolio/tree/main/exercises/javascript/calculator"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-primary inline-flex items-center gap-2"
              >
                <Github className="w-4 h-4" />
                查看源码
              </a>
              <p className="text-xs text-gray-500 mt-2">
                包含完整的实现代码和注释说明
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}