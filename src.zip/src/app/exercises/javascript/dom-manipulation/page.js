'use client'

import { useState, useRef } from 'react'
import Link from 'next/link'
import { ArrowLeft, Plus, Trash2, Edit3, Palette } from 'lucide-react'

export default function DomManipulationExercise() {
  const [elements, setElements] = useState([
    { id: 1, text: '示例元素 1', color: 'bg-blue-500' },
    { id: 2, text: '示例元素 2', color: 'bg-green-500' },
    { id: 3, text: '示例元素 3', color: 'bg-purple-500' }
  ])
  const [newElementText, setNewElementText] = useState('')
  const [editingId, setEditingId] = useState(null)
  const [editText, setEditText] = useState('')
  const nextIdRef = useRef(4)

  const colors = [
    'bg-blue-500', 'bg-green-500', 'bg-purple-500', 'bg-red-500',
    'bg-yellow-500', 'bg-pink-500', 'bg-indigo-500', 'bg-orange-500'
  ]

  // 添加元素
  const addElement = () => {
    if (newElementText.trim()) {
      const randomColor = colors[Math.floor(Math.random() * colors.length)]
      setElements([...elements, {
        id: nextIdRef.current++,
        text: newElementText.trim(),
        color: randomColor
      }])
      setNewElementText('')
    }
  }

  // 删除元素
  const deleteElement = (id) => {
    setElements(elements.filter(el => el.id !== id))
  }

  // 开始编辑
  const startEdit = (id, text) => {
    setEditingId(id)
    setEditText(text)
  }

  // 保存编辑
  const saveEdit = () => {
    if (editText.trim()) {
      setElements(elements.map(el => 
        el.id === editingId ? { ...el, text: editText.trim() } : el
      ))
    }
    setEditingId(null)
    setEditText('')
  }

  // 取消编辑
  const cancelEdit = () => {
    setEditingId(null)
    setEditText('')
  }

  // 改变元素颜色
  const changeColor = (id) => {
    const randomColor = colors[Math.floor(Math.random() * colors.length)]
    setElements(elements.map(el => 
      el.id === id ? { ...el, color: randomColor } : el
    ))
  }

  // 处理键盘事件
  const handleKeyPress = (e, action) => {
    if (e.key === 'Enter') {
      action()
    }
  }

  return (
    <div className="max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex items-center gap-4 mb-8">
        <Link 
          href="/exercises/javascript"
          className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
        </Link>
        <div>
          <h1 className="text-3xl font-bold text-gray-900">DOM 元素操作</h1>
          <p className="text-gray-600 mt-1">
            JavaScript DOM API练习 - 元素的创建、修改、删除和样式控制
          </p>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Main Demo Area */}
        <div className="lg:col-span-2">
          <div className="card">
            <div className="card-header">
              <h2 className="text-xl font-semibold">DOM操作演示</h2>
              <p className="text-sm text-gray-600 mt-1">
                实时演示JavaScript DOM操作的各种功能
              </p>
            </div>
            
            <div className="card-body">
              {/* Add Element Section */}
              <div className="mb-8 p-4 bg-gray-50 rounded-lg">
                <h3 className="font-semibold text-gray-900 mb-3">添加新元素</h3>
                <div className="flex gap-3">
                  <input
                    type="text"
                    value={newElementText}
                    onChange={(e) => setNewElementText(e.target.value)}
                    onKeyPress={(e) => handleKeyPress(e, addElement)}
                    placeholder="输入元素文本..."
                    className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                  />
                  <button
                    onClick={addElement}
                    className="btn-primary flex items-center gap-2"
                    disabled={!newElementText.trim()}
                  >
                    <Plus className="w-4 h-4" />
                    添加
                  </button>
                </div>
              </div>

              {/* Elements Display */}
              <div className="space-y-4">
                <h3 className="font-semibold text-gray-900">动态元素列表</h3>
                
                {elements.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    <div className="text-4xl mb-2">📦</div>
                    <p>还没有元素，点击上方添加按钮创建第一个元素</p>
                  </div>
                ) : (
                  <div className="grid gap-4">
                    {elements.map((element) => (
                      <div
                        key={element.id}
                        className={`${element.color} text-white p-4 rounded-lg transform transition-all duration-300 hover:scale-105 hover:shadow-lg`}
                      >
                        <div className="flex items-center justify-between">
                          {editingId === element.id ? (
                            <div className="flex-1 flex gap-2">
                              <input
                                type="text"
                                value={editText}
                                onChange={(e) => setEditText(e.target.value)}
                                onKeyPress={(e) => handleKeyPress(e, saveEdit)}
                                className="flex-1 px-3 py-1 text-gray-900 rounded"
                                autoFocus
                              />
                              <button
                                onClick={saveEdit}
                                className="px-3 py-1 bg-white/20 hover:bg-white/30 rounded text-sm"
                              >
                                保存
                              </button>
                              <button
                                onClick={cancelEdit}
                                className="px-3 py-1 bg-white/20 hover:bg-white/30 rounded text-sm"
                              >
                                取消
                              </button>
                            </div>
                          ) : (
                            <>
                              <span className="font-medium text-lg">
                                {element.text}
                              </span>
                              <div className="flex gap-2">
                                <button
                                  onClick={() => changeColor(element.id)}
                                  className="p-2 bg-white/20 hover:bg-white/30 rounded transition-colors"
                                  title="改变颜色"
                                >
                                  <Palette className="w-4 h-4" />
                                </button>
                                <button
                                  onClick={() => startEdit(element.id, element.text)}
                                  className="p-2 bg-white/20 hover:bg-white/30 rounded transition-colors"
                                  title="编辑文本"
                                >
                                  <Edit3 className="w-4 h-4" />
                                </button>
                                <button
                                  onClick={() => deleteElement(element.id)}
                                  className="p-2 bg-white/20 hover:bg-white/30 rounded transition-colors"
                                  title="删除元素"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </div>
                            </>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Stats */}
              <div className="mt-8 p-4 bg-blue-50 rounded-lg">
                <h4 className="font-semibold text-blue-900 mb-2">统计信息</h4>
                <div className="grid grid-cols-3 gap-4 text-sm">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-600">{elements.length}</div>
                    <div className="text-blue-700">总元素数</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">{nextIdRef.current - 1}</div>
                    <div className="text-green-700">已创建元素</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-orange-600">
                      {Math.max(0, nextIdRef.current - 1 - elements.length)}
                    </div>
                    <div className="text-orange-700">已删除元素</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Information Panel */}
        <div className="space-y-6">
          {/* Technical Points */}
          <div className="card">
            <div className="card-header">
              <h3 className="font-semibold">技术要点</h3>
            </div>
            <div className="card-body">
              <div className="space-y-4 text-sm">
                <div>
                  <h4 className="font-medium text-gray-900 mb-1">DOM选择器</h4>
                  <p className="text-gray-600">使用querySelector和getElementById选择元素</p>
                </div>
                <div>
                  <h4 className="font-medium text-gray-900 mb-1">元素操作</h4>
                  <p className="text-gray-600">createElement、appendChild、removeChild等方法</p>
                </div>
                <div>
                  <h4 className="font-medium text-gray-900 mb-1">事件处理</h4>
                  <p className="text-gray-600">addEventListener绑定用户交互事件</p>
                </div>
                <div>
                  <h4 className="font-medium text-gray-900 mb-1">样式控制</h4>
                  <p className="text-gray-600">动态修改className和style属性</p>
                </div>
              </div>
            </div>
          </div>

          {/* DOM API Reference */}
          <div className="card">
            <div className="card-header">
              <h3 className="font-semibold">DOM API 参考</h3>
            </div>
            <div className="card-body">
              <div className="space-y-3 text-sm">
                <div>
                  <code className="bg-gray-100 px-2 py-1 rounded">document.createElement()</code>
                  <p className="text-gray-600 mt-1">创建新的DOM元素</p>
                </div>
                <div>
                  <code className="bg-gray-100 px-2 py-1 rounded">element.appendChild()</code>
                  <p className="text-gray-600 mt-1">添加子元素</p>
                </div>
                <div>
                  <code className="bg-gray-100 px-2 py-1 rounded">element.removeChild()</code>
                  <p className="text-gray-600 mt-1">删除子元素</p>
                </div>
                <div>
                  <code className="bg-gray-100 px-2 py-1 rounded">element.textContent</code>
                  <p className="text-gray-600 mt-1">设置或获取文本内容</p>
                </div>
                <div>
                  <code className="bg-gray-100 px-2 py-1 rounded">element.className</code>
                  <p className="text-gray-600 mt-1">控制CSS类名</p>
                </div>
              </div>
            </div>
          </div>

          {/* Learning Outcomes */}
          <div className="card">
            <div className="card-header">
              <h3 className="font-semibold">学习成果</h3>
            </div>
            <div className="card-body">
              <ul className="text-sm text-gray-600 space-y-2">
                <li>• 掌握DOM元素的创建和删除</li>
                <li>• 理解事件监听和处理机制</li>
                <li>• 学会动态修改元素样式</li>
                <li>• 实践用户交互响应</li>
                <li>• 体验JavaScript控制页面的能力</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}