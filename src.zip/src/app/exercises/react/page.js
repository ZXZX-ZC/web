import Link from 'next/link'
import { ArrowLeft, Code2, Component, Layers, Zap } from 'lucide-react'

export const metadata = {
  title: 'React 组件化练习 - Course Portfolio',
  description: '展示React核心概念和组件化开发练习，包括组件设计、状态管理、生命周期等现代前端框架技能',
}

const exercises = [
  {
    id: 'components-demo',
    title: '组件基础示例',
    description: '学习React组件的创建、属性传递和基本组合模式',
    difficulty: '初级',
    duration: '3小时',
    skills: ['JSX语法', '组件属性', '事件处理', '条件渲染'],
    concepts: ['组件思维', '单向数据流', '纯函数组件', '组件组合'],
    features: [
      '函数组件和类组件对比',
      'Props属性传递和验证',
      '事件处理和数据绑定',
      '条件渲染和列表渲染'
    ],
    demo: '/exercises/react/components-demo'
  },
  {
    id: 'hooks-demo',
    title: 'Hooks 状态管理',
    description: '掌握React Hooks的使用，实现复杂的状态逻辑和副作用处理',
    difficulty: '中级',
    duration: '4小时',
    skills: ['useState', 'useEffect', '自定义Hook', '性能优化'],
    concepts: ['状态管理', '副作用处理', 'Hook规则', '组件优化'],
    features: [
      '基础Hooks的综合应用',
      '自定义Hook封装逻辑',
      'useEffect处理副作用',
      'useMemo和useCallback优化'
    ],
    demo: '/exercises/react/hooks-demo'
  },
  {
    id: 'state-management',
    title: '状态管理进阶',
    description: '学习复杂应用的状态管理模式，包括Context API和状态提升',
    difficulty: '高级',
    duration: '6小时',
    skills: ['Context API', 'useReducer', '状态提升', '组件通信'],
    concepts: ['全局状态', '状态架构', '数据流管理', '性能优化'],
    features: [
      'Context API实现全局状态',
      'useReducer管理复杂状态',
      '组件间通信模式',
      '状态管理最佳实践'
    ],
    demo: '/exercises/react/state-management'
  }
]

const reactConcepts = [
  {
    category: '核心概念',
    items: [
      { name: '组件化思维', desc: '将UI拆分为可复用的独立组件' },
      { name: 'JSX语法', desc: '在JavaScript中编写类似HTML的语法' },
      { name: '虚拟DOM', desc: '高效的DOM更新和渲染机制' },
      { name: '单向数据流', desc: '数据从父组件流向子组件的模式' }
    ]
  },
  {
    category: '状态管理',
    items: [
      { name: 'useState', desc: '管理组件内部状态的Hook' },
      { name: 'useEffect', desc: '处理副作用和生命周期的Hook' },
      { name: 'Context API', desc: '跨组件共享状态的机制' },
      { name: 'useReducer', desc: '管理复杂状态逻辑的Hook' }
    ]
  },
  {
    category: '性能优化',
    items: [
      { name: 'React.memo', desc: '避免不必要的组件重新渲染' },
      { name: 'useMemo', desc: '缓存计算结果避免重复计算' },
      { name: 'useCallback', desc: '缓存函数引用避免子组件重渲染' },
      { name: 'Code Splitting', desc: '按需加载组件提升性能' }
    ]
  }
]

export default function ReactPage() {
  return (
    <div className="max-w-6xl mx-auto">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-sm text-gray-600 mb-6">
        <Link href="/exercises" className="hover:text-primary-600">
          课程练习
        </Link>
        <span>/</span>
        <span className="text-gray-900">React 组件化</span>
      </div>

      {/* Header */}
      <div className="flex items-center gap-4 mb-8">
        <Link 
          href="/exercises"
          className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
        </Link>
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-500 rounded-lg flex items-center justify-center">
              <Code2 className="w-5 h-5 text-white" />
            </div>
            React 组件化练习
          </h1>
          <p className="text-gray-600 mt-2">
            掌握React框架核心概念，学习组件化开发和现代前端架构设计
          </p>
        </div>
      </div>

      {/* React Philosophy */}
      <div className="card mb-8 bg-gradient-to-r from-blue-50 to-purple-50">
        <div className="card-body">
          <div className="flex items-center gap-3 mb-4">
            <Component className="w-6 h-6 text-blue-600" />
            <h2 className="text-xl font-semibold text-gray-900">React 设计理念</h2>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
                <Component className="w-6 h-6 text-blue-600" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">组件化</h3>
              <p className="text-gray-600 text-sm">
                将复杂的UI拆分为小的、可复用的组件，提高代码的可维护性
              </p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-3">
                <Layers className="w-6 h-6 text-purple-600" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">声明式</h3>
              <p className="text-gray-600 text-sm">
                描述UI应该是什么样子，而不是如何去更新它，让代码更易理解
              </p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
                <Zap className="w-6 h-6 text-green-600" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">高效渲染</h3>
              <p className="text-gray-600 text-sm">
                通过虚拟DOM和Diff算法，实现高效的DOM更新和优化性能
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* React Concepts */}
      <div className="card mb-8">
        <div className="card-header">
          <h2 className="text-xl font-semibold">核心概念图谱</h2>
        </div>
        <div className="card-body">
          <div className="grid md:grid-cols-3 gap-8">
            {reactConcepts.map((category, index) => (
              <div key={index}>
                <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
                  <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                  {category.category}
                </h3>
                <div className="space-y-3">
                  {category.items.map((item, i) => (
                    <div key={i} className="border-l-2 border-gray-200 pl-3">
                      <div className="font-medium text-gray-800 text-sm">{item.name}</div>
                      <div className="text-gray-600 text-xs mt-1">{item.desc}</div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Exercises */}
      <div className="space-y-8">
        {exercises.map((exercise, index) => (
          <div key={exercise.id} className="card overflow-hidden">
            <div className="md:flex">
              {/* Exercise Preview */}
              <div className="md:w-1/3 bg-gradient-to-br from-blue-50 to-purple-50 p-6 flex items-center justify-center">
                <div className="text-center">
                  <div className="w-24 h-24 bg-gradient-to-r from-blue-500 to-purple-500 rounded-xl flex items-center justify-center mx-auto mb-4">
                    <Code2 className="w-12 h-12 text-white" />
                  </div>
                  <p className="text-sm text-gray-600">练习 {index + 1}</p>
                  <p className="text-xs text-gray-500 mt-1">{exercise.duration}</p>
                </div>
              </div>

              {/* Exercise Content */}
              <div className="md:w-2/3 p-6">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">
                      {exercise.title}
                    </h3>
                    <p className="text-gray-600 mb-3">
                      {exercise.description}
                    </p>
                  </div>
                  <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-xs font-medium ml-4">
                    {exercise.difficulty}
                  </span>
                </div>

                {/* Skills & Concepts */}
                <div className="grid md:grid-cols-2 gap-4 mb-4">
                  <div>
                    <h4 className="text-sm font-medium text-gray-900 mb-2">技术技能</h4>
                    <div className="flex flex-wrap gap-1">
                      {exercise.skills.map((skill, i) => (
                        <span key={i} className="bg-blue-50 text-blue-700 px-2 py-1 rounded text-xs">
                          {skill}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-gray-900 mb-2">核心概念</h4>
                    <div className="flex flex-wrap gap-1">
                      {exercise.concepts.map((concept, i) => (
                        <span key={i} className="bg-purple-50 text-purple-700 px-2 py-1 rounded text-xs">
                          {concept}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Features */}
                <div className="mb-6">
                  <h4 className="text-sm font-medium text-gray-900 mb-2">学习要点</h4>
                  <ul className="text-sm text-gray-600 space-y-1">
                    {exercise.features.map((feature, i) => (
                      <li key={i} className="flex items-center gap-2">
                        <div className="w-1 h-1 bg-blue-400 rounded-full"></div>
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Action Button */}
                <Link
                  href={exercise.demo}
                  className="btn-primary flex items-center gap-2 text-sm w-fit"
                >
                  <Component className="w-4 h-4" />
                  交互演示
                </Link>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* React Ecosystem */}
      <div className="mt-12 card">
        <div className="card-header">
          <h2 className="text-xl font-semibold">React 生态系统</h2>
        </div>
        <div className="card-body">
          <div className="grid md:grid-cols-4 gap-6">
            <div>
              <h3 className="font-semibold text-gray-900 mb-3">开发工具</h3>
              <ul className="space-y-2 text-sm text-gray-600">
                <li>• React DevTools</li>
                <li>• Create React App</li>
                <li>• Vite</li>
                <li>• Webpack</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold text-gray-900 mb-3">状态管理</h3>
              <ul className="space-y-2 text-sm text-gray-600">
                <li>• Redux Toolkit</li>
                <li>• Zustand</li>
                <li>• Jotai</li>
                <li>• Context API</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold text-gray-900 mb-3">路由管理</h3>
              <ul className="space-y-2 text-sm text-gray-600">
                <li>• React Router</li>
                <li>• Next.js Router</li>
                <li>• Reach Router</li>
                <li>• Wouter</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold text-gray-900 mb-3">UI组件库</h3>
              <ul className="space-y-2 text-sm text-gray-600">
                <li>• Material-UI</li>
                <li>• Ant Design</li>
                <li>• Chakra UI</li>
                <li>• React Bootstrap</li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* Best Practices */}
      <div className="mt-8 card bg-gradient-to-r from-blue-50 to-purple-50">
        <div className="card-header">
          <h3 className="text-xl font-semibold">React 最佳实践</h3>
        </div>
        <div className="card-body">
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold text-gray-900 mb-3">组件设计</h4>
              <ul className="space-y-2 text-sm text-gray-600">
                <li>• 保持组件小而专注</li>
                <li>• 使用有意义的组件命名</li>
                <li>• 遵循单一职责原则</li>
                <li>• 优先使用函数组件</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-gray-900 mb-3">性能优化</h4>
              <ul className="space-y-2 text-sm text-gray-600">
                <li>• 合理使用React.memo</li>
                <li>• 避免在render中创建对象</li>
                <li>• 使用useCallback缓存函数</li>
                <li>• 实现虚拟滚动处理大列表</li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* Next Steps */}
      <div className="mt-8 card bg-gradient-to-r from-blue-50 to-purple-50">
        <div className="card-body text-center">
          <h3 className="text-xl font-semibold text-gray-900 mb-4">学习完成！</h3>
          <p className="text-gray-600 mb-6">
            恭喜完成React组件化开发的学习！现在您已经掌握了现代前端开发的核心技能，
            可以开始构建复杂的Web应用了。
          </p>
          <div className="flex justify-center gap-4">
            <Link href="/exercises" className="btn-secondary">
              返回练习总览
            </Link>
            <Link href="/qanything" className="btn-primary">
              体验AI问答 →
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}