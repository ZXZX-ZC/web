import { NextResponse } from 'next/server'

const WAKATIME_API_KEY = process.env.WAKATIME_API_KEY
const WAKATIME_USERNAME = process.env.WAKATIME_USERNAME

// 缓存数据，避免频繁请求API
let cachedData = null
let cacheTimestamp = null
const CACHE_DURATION = 15 * 60 * 1000 // 15分钟缓存

export async function GET() {
  try {
    // 检查缓存
    if (cachedData && cacheTimestamp && (Date.now() - cacheTimestamp < CACHE_DURATION)) {
      return NextResponse.json(cachedData)
    }

    // 检查环境变量
    if (!WAKATIME_API_KEY) {
      console.warn('WAKATIME_API_KEY not configured')
      return NextResponse.json(getMockData(), { status: 200 })
    }

    const headers = {
      'Authorization': `Bearer ${WAKATIME_API_KEY}`,
      'Content-Type': 'application/json',
    }

    // 获取用户统计信息
    const baseUrl = 'https://wakatime.com/api/v1'
    const endpoints = {
      today: `${baseUrl}/users/current/summaries?start=today&end=today`,
      week: `${baseUrl}/users/current/summaries?start=today&end=today&range=last_7_days`,
      allTime: `${baseUrl}/users/current/all_time_since_today`,
      stats: `${baseUrl}/users/current/stats/last_7_days`
    }

    // 并行请求多个端点
    const requests = await Promise.allSettled([
      fetch(endpoints.today, { headers }),
      fetch(endpoints.week, { headers }),
      fetch(endpoints.allTime, { headers }),
      fetch(endpoints.stats, { headers })
    ])

    // 解析响应
    const responses = await Promise.allSettled(
      requests.map(async (result, index) => {
        if (result.status === 'fulfilled' && result.value.ok) {
          return await result.value.json()
        }
        return null
      })
    )

    const [todayData, weekData, allTimeData, statsData] = responses.map(r => 
      r.status === 'fulfilled' ? r.value : null
    )

    // 处理数据
    const processedData = {
      today: getTotalSeconds(todayData?.data?.[0]?.grand_total?.total_seconds || 0),
      week: getTotalSeconds(weekData?.data?.reduce((sum, day) => 
        sum + (day.grand_total?.total_seconds || 0), 0) || 0),
      total: getTotalSeconds(allTimeData?.data?.total_seconds || 0),
      topLanguage: getTopLanguage(statsData?.data?.languages),
      languages: getLanguagesData(statsData?.data?.languages),
      lastUpdate: new Date().toISOString()
    }

    // 更新缓存
    cachedData = processedData
    cacheTimestamp = Date.now()

    return NextResponse.json(processedData)

  } catch (error) {
    console.error('WakaTime API Error:', error)
    
    // 返回模拟数据作为后备
    return NextResponse.json(getMockData(), { status: 200 })
  }
}

function getTotalSeconds(seconds) {
  return Math.max(0, Math.floor(seconds || 0))
}

function getTopLanguage(languages) {
  if (!languages || languages.length === 0) return 'JavaScript'
  return languages[0]?.name || 'JavaScript'
}

function getLanguagesData(languages) {
  if (!languages || languages.length === 0) {
    return [
      { name: 'JavaScript', percent: 45, color: '#f7df1e' },
      { name: 'HTML', percent: 25, color: '#e34f26' },
      { name: 'CSS', percent: 20, color: '#1572b6' },
      { name: 'JSON', percent: 10, color: '#000000' }
    ]
  }

  return languages.slice(0, 10).map(lang => ({
    name: lang.name,
    percent: Math.round(lang.percent * 100) / 100,
    color: getLanguageColor(lang.name)
  }))
}

function getLanguageColor(language) {
  const colors = {
    'JavaScript': '#f7df1e',
    'TypeScript': '#3178c6',
    'HTML': '#e34f26',
    'CSS': '#1572b6',
    'React': '#61dafb',
    'Vue': '#4fc08d',
    'Python': '#3776ab',
    'Java': '#007396',
    'JSON': '#000000',
    'Markdown': '#083fa1',
    'SCSS': '#cf649a',
    'Less': '#1d365d'
  }
  return colors[language] || '#6B7280'
}

// 模拟数据，用于演示或API不可用时
function getMockData() {
  const now = new Date()
  const mockTodayHours = 3.5 + Math.random() * 2 // 3.5-5.5小时
  const mockWeekHours = 25 + Math.random() * 10 // 25-35小时
  const mockTotalHours = 280 + Math.random() * 50 // 280-330小时

  return {
    today: Math.floor(mockTodayHours * 3600),
    week: Math.floor(mockWeekHours * 3600),
    total: Math.floor(mockTotalHours * 3600),
    topLanguage: 'JavaScript',
    languages: [
      { name: 'JavaScript', percent: 42.5, color: '#f7df1e' },
      { name: 'HTML', percent: 23.8, color: '#e34f26' },
      { name: 'CSS', percent: 18.2, color: '#1572b6' },
      { name: 'JSON', percent: 8.1, color: '#000000' },
      { name: 'Markdown', percent: 4.6, color: '#083fa1' },
      { name: 'TypeScript', percent: 2.8, color: '#3178c6' }
    ],
    lastUpdate: now.toISOString(),
    _isMockData: true
  }
}