'use client'

import { useState, useEffect } from 'react'
import { Sparkles, MessageSquare, Brain, Zap, Wifi, WifiOff, AlertCircle } from 'lucide-react'
import ChatInterface from '@/components/qanything/ChatInterface'

// API状态指示器组件
function APIStatusIndicator() {
  const [status, setStatus] = useState({ connectionStatus: 'checking', message: '检查中...' })
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    checkApiStatus()
  }, [])

  const checkApiStatus = async () => {
    try {
      setIsLoading(true)
      const response = await fetch('/api/qanything/test')
      const data = await response.json()
      setStatus(data)
    } catch (error) {
      setStatus({
        connectionStatus: 'error',
        message: '无法检查API状态'
      })
    } finally {
      setIsLoading(false)
    }
  }

  const getStatusDisplay = () => {
    if (isLoading) {
      return {
        icon: AlertCircle,
        color: 'text-gray-500',
        bgColor: 'bg-gray-100',
        text: '检查中...'
      }
    }

    switch (status.connectionStatus) {
      case 'connected':
        return {
          icon: Wifi,
          color: 'text-green-600',
          bgColor: 'bg-green-100',
          text: '真实API已连接'
        }
      case 'demo_mode':
        return {
          icon: Brain,
          color: 'text-blue-600',
          bgColor: 'bg-blue-100',
          text: '演示模式'
        }
      default:
        return {
          icon: WifiOff,
          color: 'text-orange-600',
          bgColor: 'bg-orange-100',
          text: '使用模拟回复'
        }
    }
  }

  const statusDisplay = getStatusDisplay()

  return (
    <div className="flex items-center gap-2">
      <div className={`${statusDisplay.bgColor} ${statusDisplay.color} p-1 rounded-full`}>
        <statusDisplay.icon className="w-3 h-3" />
      </div>
      <span className="text-sm text-gray-600">{statusDisplay.text}</span>
      {!isLoading && (
        <button
          onClick={checkApiStatus}
          className="text-xs text-gray-400 hover:text-gray-600 ml-1"
          title="重新检查状态"
        >
          🔄
        </button>
      )}
    </div>
  )
}

export const metadata = {
  title: 'QAnything AI问答 - Course Portfolio',
  description: '基于QAnything大语言模型的智能问答服务，提供专业的AI对话体验',
}

export default function QAnythingPage() {
  return (
    <div className="max-w-6xl mx-auto">
      {/* Header Section */}
      <div className="text-center mb-8">
        <div className="flex items-center justify-center mb-4">
          <div className="w-16 h-16 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full flex items-center justify-center">
            <Sparkles className="w-8 h-8 text-white" />
          </div>
        </div>
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          QAnything AI问答
        </h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          基于先进大语言模型的智能问答服务，支持多轮对话、上下文理解，
          为您提供准确、有用的信息和建议
        </p>
      </div>

      {/* Features Grid */}
      <div className="grid md:grid-cols-3 gap-6 mb-8">
        <div className="card text-center">
          <div className="card-body">
            <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <MessageSquare className="w-6 h-6 text-blue-600" />
            </div>
            <h3 className="text-lg font-semibold mb-2">智能对话</h3>
            <p className="text-gray-600 text-sm">
              支持自然语言交互，理解上下文语境，提供连贯的多轮对话体验
            </p>
          </div>
        </div>

        <div className="card text-center">
          <div className="card-body">
            <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Brain className="w-6 h-6 text-green-600" />
            </div>
            <h3 className="text-lg font-semibold mb-2">知识问答</h3>
            <p className="text-gray-600 text-sm">
              覆盖广泛的知识领域，包括编程、学习方法、技术问题等专业内容
            </p>
          </div>
        </div>

        <div className="card text-center">
          <div className="card-body">
            <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Zap className="w-6 h-6 text-purple-600" />
            </div>
            <h3 className="text-lg font-semibold mb-2">快速响应</h3>
            <p className="text-gray-600 text-sm">
              采用高效的API调用机制，确保快速响应和稳定的服务体验
            </p>
          </div>
        </div>
      </div>

      {/* Chat Interface */}
      <div className="card">
        <div className="card-header">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-semibold flex items-center gap-2">
                <MessageSquare className="w-5 h-5 text-purple-600" />
                开始对话
              </h2>
              <p className="text-sm text-gray-600 mt-1">
                输入您的问题，AI助手将为您提供详细的回答和建议
              </p>
            </div>
            <APIStatusIndicator />
          </div>
        </div>
        <div className="card-body p-0">
          <ChatInterface />
        </div>
      </div>

      {/* Usage Tips */}
      <div className="mt-8 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">使用提示</h3>
        <div className="grid md:grid-cols-3 gap-6">
          <div>
            <h4 className="font-medium text-gray-800 mb-2">💡 提问技巧</h4>
            <ul className="text-sm text-gray-600 space-y-1">
              <li>• 描述具体、清晰的问题</li>
              <li>• 提供必要的背景信息</li>
              <li>• 可以进行多轮对话深入探讨</li>
            </ul>
          </div>
          <div>
            <h4 className="font-medium text-gray-800 mb-2">🎯 适用场景</h4>
            <ul className="text-sm text-gray-600 space-y-1">
              <li>• 编程技术问题咨询</li>
              <li>• 学习方法和建议</li>
              <li>• 概念解释和知识问答</li>
            </ul>
          </div>
          <div>
            <h4 className="font-medium text-gray-800 mb-2">🔧 服务状态</h4>
            <ul className="text-sm text-gray-600 space-y-1">
              <li>• 当前运行在演示模式</li>
              <li>• 使用智能模拟回复系统</li>
              <li>• 支持配置真实QAnything API</li>
            </ul>
          </div>
        </div>
        
        <div className="mt-4 p-3 bg-blue-100 rounded-lg">
          <p className="text-sm text-blue-800">
            <strong>演示说明：</strong> 
            当前使用增强的模拟回复系统，可以智能识别问题类型并给出相关回答。
            若要启用真实的QAnything API，请在环境变量中配置 <code className="bg-blue-200 px-1 rounded">QANYTHING_API_URL</code> 和 <code className="bg-blue-200 px-1 rounded">QANYTHING_API_KEY</code>。
          </p>
        </div>
        
        <div className="mt-3 text-center">
          <a 
            href="/api/qanything/test" 
            target="_blank" 
            rel="noopener noreferrer"
            className="text-xs text-blue-600 hover:text-blue-800 underline"
          >
            查看API连接状态 →
          </a>
        </div>
      </div>
    </div>
  )
}