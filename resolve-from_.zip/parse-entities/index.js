// Note: more types exposed from `index.d.ts`.
// To do: refactor to include type parameters in JS.
export {parseEntities} from './lib/index.js'
