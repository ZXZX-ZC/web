export { default } from "./lib/index.js";
export type Options = import("./lib/index.js").Options;
export { defaultFootnoteBackContent, defaultFootnoteBackLabel, defaultHandlers } from "mdast-util-to-hast";
//# sourceMappingURL=index.d.ts.map