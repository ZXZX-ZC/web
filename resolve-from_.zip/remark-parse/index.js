// Note: types exposed from `index.d.ts`.
export {default} from './lib/index.js'
