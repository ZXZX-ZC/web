declare function isDataView(value: unknown): value is DataView;

export = isDataView;