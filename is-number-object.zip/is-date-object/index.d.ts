declare function isDateObject(value: unknown): value is Date;

export = isDateObject;
