declare function isNumberObject(value: unknown): value is (number | Number);

export = isNumberObject;
