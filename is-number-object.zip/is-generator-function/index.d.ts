declare function isGeneratorFunction(fn: unknown): fn is GeneratorFunction;

export = isGeneratorFunction;