// Note: types exposed from `index.d.ts`.
export {handlers as defaultHandlers} from './lib/handlers/index.js'
export {toHast} from './lib/index.js'
export {
  defaultFootnoteBackContent,
  defaultFootnoteBackLabel
} from './lib/footer.js'
