export function phrasing(node?: unknown): node is import("mdast").Break | import("mdast").Delete | import("mdast").Emphasis | import("mdast").FootnoteReference | import("mdast").Image | import("mdast").ImageReference | import("mdast").InlineCode | import("mdast").Link | import("mdast").LinkReference | import("mdast").Strong | import("mdast").Text;
export type Html = import('mdast').Html;
export type PhrasingContent = import('mdast').PhrasingContent;
