export { phrasing } from "./lib/index.js";
