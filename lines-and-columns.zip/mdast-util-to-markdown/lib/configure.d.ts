/**
 * @param {State} base
 * @param {Options} extension
 * @returns {State}
 */
export function configure(base: State, extension: Options): State;
import type { State } from './types.js';
import type { Options } from './types.js';
//# sourceMappingURL=configure.d.ts.map