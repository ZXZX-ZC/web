/**
 * @param {Html} node
 * @returns {string}
 */
export function html(node: Html): string;
export namespace html {
    export { htmlPeek as peek };
}
import type { Html } from 'mdast';
/**
 * @returns {string}
 */
declare function htmlPeek(): string;
export {};
//# sourceMappingURL=html.d.ts.map