/**
 * @param {ThematicBreak} _
 * @param {Parents | undefined} _1
 * @param {State} state
 * @returns {string}
 */
export function thematicBreak(_: ThematicBreak, _1: Parents | undefined, state: State): string;
import type { ThematicBreak } from 'mdast';
import type { Parents } from 'mdast';
import type { State } from 'mdast-util-to-markdown';
//# sourceMappingURL=thematic-break.d.ts.map