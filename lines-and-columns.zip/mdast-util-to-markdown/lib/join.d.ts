/** @type {Array<Join>} */
export const join: Array<Join>;
import type { Join } from 'mdast-util-to-markdown';
//# sourceMappingURL=join.d.ts.map