export function track(info: import("../types.js").TrackFields): import("../types.js").Tracker;
//# sourceMappingURL=track.d.ts.map