/**
 * @import {State} from 'mdast-util-to-markdown'
 * @import {Code} from 'mdast'
 */
/**
 * @param {Code} node
 * @param {State} state
 * @returns {boolean}
 */
export function formatCodeAsIndented(node: Code, state: State): boolean;
import type { Code } from 'mdast';
import type { State } from 'mdast-util-to-markdown';
//# sourceMappingURL=format-code-as-indented.d.ts.map