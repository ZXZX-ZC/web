/**
 * @this {State}
 * @returns {'*' | '_'}
 */
export function emphasisStrongMarker(this: State): "*" | "_";
import type { State } from '../types.js';
//# sourceMappingURL=emphasis-strong-marker.d.ts.map