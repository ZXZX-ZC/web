export function association(node: import("mdast").Association): string;
//# sourceMappingURL=association.d.ts.map