export function compilePattern(info: import("../types.js").Unsafe): RegExp;
//# sourceMappingURL=compile-pattern.d.ts.map