/**
 * @import {Options, State} from 'mdast-util-to-markdown'
 */
/**
 * @param {State} state
 * @returns {Exclude<Options['quote'], null | undefined>}
 */
export function checkQuote(state: State): Exclude<Options["quote"], null | undefined>;
import type { State } from 'mdast-util-to-markdown';
import type { Options } from 'mdast-util-to-markdown';
//# sourceMappingURL=check-quote.d.ts.map