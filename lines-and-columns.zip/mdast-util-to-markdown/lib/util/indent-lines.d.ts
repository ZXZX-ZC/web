export function indentLines(value: string, map: import("../types.js").Map): string;
//# sourceMappingURL=indent-lines.d.ts.map