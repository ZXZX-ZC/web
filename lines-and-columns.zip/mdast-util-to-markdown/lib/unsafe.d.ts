/** @type {Array<Unsafe>} */
export const unsafe: Array<Unsafe>;
import type { Unsafe } from 'mdast-util-to-markdown';
//# sourceMappingURL=unsafe.d.ts.map