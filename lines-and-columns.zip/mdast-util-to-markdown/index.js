// Note: extra types exposed from `index.d.ts`.
export {toMarkdown} from './lib/index.js'
export {handle as defaultHandlers} from './lib/handle/index.js'
