/**
 * @typedef {import('./lib/index.js').Options} Options
 */

export {toString} from './lib/index.js'
