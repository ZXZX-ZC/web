// Note: types exported from `index.d.ts`.
export {fromMarkdown} from './lib/index.js'
