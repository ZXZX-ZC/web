require('./lib/eslint-bulk-suppressions');
