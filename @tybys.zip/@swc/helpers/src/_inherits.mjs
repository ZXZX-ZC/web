export { _ as default } from "../esm/_inherits.js";
