export { _ as default } from "../esm/_unsupported_iterable_to_array.js";
