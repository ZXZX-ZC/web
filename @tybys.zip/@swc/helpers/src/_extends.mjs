export { _ as default } from "../esm/_extends.js";
