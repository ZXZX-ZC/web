export { _ as default } from "../esm/_tagged_template_literal.js";
