# Installation
> `npm install --save @types/hast`

# Summary
This package contains type definitions for hast (https://github.com/syntax-tree/hast).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/hast.

### Additional Details
 * Last updated: Tue, 30 Jan 2024 21:35:45 GMT
 * Dependencies: [@types/unist](https://npmjs.com/package/@types/unist)

# Credits
These definitions were written by [lukeggchapman](https://github.com/lukeggchapman), [Junyoung Choi](https://github.com/rokt33r), [Christian Murphy](https://github.com/ChristianMurphy), and [Remco Haszing](https://github.com/remcohaszing).
