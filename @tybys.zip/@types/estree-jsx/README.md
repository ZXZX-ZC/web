# Installation
> `npm install --save @types/estree-jsx`

# Summary
This package contains type definitions for estree-jsx (https://github.com/facebook/jsx).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/estree-jsx.

### Additional Details
 * Last updated: Fri, 23 Feb 2024 02:11:41 GMT
 * Dependencies: [@types/estree](https://npmjs.com/package/@types/estree)

# Credits
These definitions were written by [Tony Ross](https://github.com/antross).
