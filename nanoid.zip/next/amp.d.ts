export * from './dist/shared/lib/amp'
