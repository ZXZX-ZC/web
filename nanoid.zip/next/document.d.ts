import Document from './dist/pages/_document'
export * from './dist/pages/_document'
export default Document
