import Link from 'next/link'
import { BookOpen, Code2, Palette, Zap, ArrowRight, Star, Calendar, Clock } from 'lucide-react'

export const metadata = {
  title: '课程练习展示 - Course Portfolio',
  description: '系统展示HTML/CSS、JavaScript、React等Web开发技术的学习成果和练习项目',
}

const exerciseCategories = [
  {
    id: 'html-css',
    title: 'HTML & CSS 基础',
    description: '掌握网页结构与样式设计，学习响应式布局和现代CSS特性',
    icon: Palette,
    color: 'from-orange-500 to-red-500',
    exercises: [
      { name: '个人简历页面', difficulty: '初级', time: '2小时' },
      { name: '响应式导航栏', difficulty: '中级', time: '3小时' },
      { name: 'CSS Grid 布局', difficulty: '中级', time: '4小时' }
    ],
    skills: ['HTML5语义化', 'CSS3动画', 'Flexbox', 'Grid布局', '响应式设计'],
    count: 3
  },
  {
    id: 'javascript',
    title: 'JavaScript 交互',
    description: '学习DOM操作、事件处理、异步编程等现代JavaScript核心技术',
    icon: Zap,
    color: 'from-yellow-500 to-orange-500',
    exercises: [
      { name: 'DOM 元素操作', difficulty: '初级', time: '2小时' },
      { name: '交互式计算器', difficulty: '中级', time: '4小时' },
      { name: '待办事项应用', difficulty: '中级', time: '5小时' }
    ],
    skills: ['DOM操作', '事件处理', 'ES6+语法', '异步编程', '本地存储'],
    count: 3
  },
  {
    id: 'react',
    title: 'React 组件化',
    description: '掌握React组件开发、状态管理、生命周期等现代前端框架核心概念',
    icon: Code2,
    color: 'from-blue-500 to-purple-500',
    exercises: [
      { name: '组件基础示例', difficulty: '初级', time: '3小时' },
      { name: 'Hooks 状态管理', difficulty: '中级', time: '4小时' },
      { name: '状态管理进阶', difficulty: '高级', time: '6小时' }
    ],
    skills: ['JSX语法', '组件设计', 'Hooks', '状态管理', '组件通信'],
    count: 3
  }
]

const stats = {
  totalExercises: 9,
  totalHours: 32,
  completedProjects: 9,
  technologies: 8
}

export default function ExercisesPage() {
  return (
    <div className="max-w-6xl mx-auto">
      {/* Header Section */}
      <div className="text-center mb-12">
        <div className="flex items-center justify-center mb-4">
          <BookOpen className="w-12 h-12 text-primary-600" />
        </div>
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          课程练习展示
        </h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          系统性展示本学期Web开发学习历程，从HTML/CSS基础到React组件化开发，
          体现完整的前端技术学习路径和实践成果
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-12">
        <div className="text-center">
          <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
            <BookOpen className="w-8 h-8 text-blue-600" />
          </div>
          <div className="text-3xl font-bold text-blue-600 mb-1">{stats.totalExercises}</div>
          <div className="text-sm text-gray-600">完成练习</div>
        </div>
        
        <div className="text-center">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
            <Clock className="w-8 h-8 text-green-600" />
          </div>
          <div className="text-3xl font-bold text-green-600 mb-1">{stats.totalHours}+</div>
          <div className="text-sm text-gray-600">学习时长</div>
        </div>
        
        <div className="text-center">
          <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-3">
            <Star className="w-8 h-8 text-purple-600" />
          </div>
          <div className="text-3xl font-bold text-purple-600 mb-1">{stats.completedProjects}</div>
          <div className="text-sm text-gray-600">项目完成</div>
        </div>
        
        <div className="text-center">
          <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-3">
            <Code2 className="w-8 h-8 text-orange-600" />
          </div>
          <div className="text-3xl font-bold text-orange-600 mb-1">{stats.technologies}</div>
          <div className="text-sm text-gray-600">技术栈</div>
        </div>
      </div>

      {/* Exercise Categories */}
      <div className="space-y-8">
        {exerciseCategories.map((category, index) => (
          <div key={category.id} className="card overflow-hidden">
            {/* Category Header */}
            <div className={`bg-gradient-to-r ${category.color} p-6 text-white`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center">
                    <category.icon className="w-6 h-6" />
                  </div>
                  <div>
                    <h2 className="text-2xl font-bold">{category.title}</h2>
                    <p className="text-white/90 mt-1">{category.description}</p>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold">{category.count}</div>
                  <div className="text-sm text-white/80">个练习</div>
                </div>
              </div>
            </div>

            {/* Category Content */}
            <div className="p-6">
              {/* Skills */}
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-3">涵盖技能</h3>
                <div className="flex flex-wrap gap-2">
                  {category.skills.map((skill, i) => (
                    <span
                      key={i}
                      className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm font-medium"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>

              {/* Exercises Grid */}
              <div className="grid md:grid-cols-3 gap-4 mb-6">
                {category.exercises.map((exercise, i) => (
                  <div key={i} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                    <h4 className="font-semibold text-gray-900 mb-2">{exercise.name}</h4>
                    <div className="flex items-center justify-between text-sm text-gray-600">
                      <div className="flex items-center gap-1">
                        <Star className="w-3 h-3" />
                        <span>{exercise.difficulty}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        <span>{exercise.time}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* View Details Button */}
              <div className="flex justify-center">
                <Link
                  href={`/exercises/${category.id}`}
                  className="btn-primary inline-flex items-center gap-2"
                >
                  查看详细内容
                  <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Learning Path */}
      <div className="mt-12 card">
        <div className="card-header">
          <h2 className="text-2xl font-semibold flex items-center gap-2">
            <Calendar className="w-6 h-6 text-primary-600" />
            学习路径
          </h2>
        </div>
        <div className="card-body">
          <div className="space-y-6">
            <div className="flex items-center gap-4">
              <div className="w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center text-white font-bold text-sm">1</div>
              <div className="flex-1">
                <h3 className="font-semibold text-gray-900">HTML & CSS 基础</h3>
                <p className="text-gray-600 text-sm">学习网页结构设计和样式美化，掌握响应式布局</p>
              </div>
              <div className="text-sm text-gray-500">第1-4周</div>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="w-8 h-8 bg-yellow-500 rounded-full flex items-center justify-center text-white font-bold text-sm">2</div>
              <div className="flex-1">
                <h3 className="font-semibold text-gray-900">JavaScript 交互</h3>
                <p className="text-gray-600 text-sm">掌握DOM操作、事件处理和现代ES6+语法特性</p>
              </div>
              <div className="text-sm text-gray-500">第5-8周</div>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white font-bold text-sm">3</div>
              <div className="flex-1">
                <h3 className="font-semibold text-gray-900">React 组件化</h3>
                <p className="text-gray-600 text-sm">学习组件化开发思想，掌握现代前端框架核心概念</p>
              </div>
              <div className="text-sm text-gray-500">第9-12周</div>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center text-white font-bold text-sm">4</div>
              <div className="flex-1">
                <h3 className="font-semibold text-gray-900">Next.js 整合</h3>
                <p className="text-gray-600 text-sm">整合所有学习成果，构建完整的全栈应用项目</p>
              </div>
              <div className="text-sm text-gray-500">第13-16周</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}