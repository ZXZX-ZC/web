import Link from 'next/link'
import { ArrowLeft, Play, Github, Code, Zap, ExternalLink } from 'lucide-react'

export const metadata = {
  title: 'JavaScript 交互练习 - Course Portfolio',
  description: '展示JavaScript核心技能练习，包括DOM操作、事件处理、异步编程等现代前端开发技术',
}

const exercises = [
  {
    id: 'dom-manipulation',
    title: 'DOM 元素操作',
    description: '学习JavaScript DOM API，掌握元素选择、创建、修改和删除的核心技能',
    difficulty: '初级',
    duration: '2小时',
    skills: ['DOM选择器', '元素操作', '事件绑定', '样式控制'],
    features: [
      '掌握querySelector和getElementById的使用',
      '学习createElement和appendChild方法',
      '实现元素属性和内容的动态修改',
      '理解事件冒泡和事件委托机制'
    ],
    concepts: ['文档对象模型', '节点操作', '事件系统', '动态内容'],
    demo: '/exercises/javascript/dom-manipulation'
  },
  {
    id: 'calculator',
    title: '交互式计算器',
    description: '构建功能完整的计算器应用，实现基本运算和高级功能',
    difficulty: '中级',
    duration: '4小时',
    skills: ['事件处理', '状态管理', '错误处理', '用户界面'],
    features: [
      '支持基本四则运算和小数运算',
      '实现键盘快捷键支持',
      '添加历史记录和清除功能',
      '处理除零错误和输入验证'
    ],
    concepts: ['函数式编程', '状态管理', '用户体验', '错误处理'],
    demo: '/exercises/javascript/calculator'
  },
  {
    id: 'todo-app',
    title: '待办事项应用',
    description: '开发完整的待办事项管理应用，实现数据持久化和过滤功能',
    difficulty: '中级',
    duration: '5小时',
    skills: ['数组操作', '本地存储', '过滤排序', 'CRUD操作'],
    features: [
      '添加、编辑、删除和标记完成任务',
      '实现任务过滤和搜索功能',
      '使用localStorage进行数据持久化',
      '添加任务统计和批量操作'
    ],
    concepts: ['数据管理', '本地存储', '用户界面', '应用架构'],
    demo: '/exercises/javascript/todo-app'
  }
]

const learningPath = [
  {
    phase: '基础语法',
    topics: ['变量与数据类型', '运算符与表达式', '控制流程', '函数定义'],
    duration: '第1周'
  },
  {
    phase: 'DOM操作',
    topics: ['元素选择', '内容修改', '样式控制', '事件处理'],
    duration: '第2周'
  },
  {
    phase: '高级特性',
    topics: ['异步编程', '模块化', 'ES6+语法', '错误处理'],
    duration: '第3周'
  },
  {
    phase: '项目实践',
    topics: ['完整应用', '数据管理', '用户体验', '性能优化'],
    duration: '第4周'
  }
]

export default function JavaScriptPage() {
  return (
    <div className="max-w-6xl mx-auto">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-sm text-gray-600 mb-6">
        <Link href="/exercises" className="hover:text-primary-600">
          课程练习
        </Link>
        <span>/</span>
        <span className="text-gray-900">JavaScript 交互</span>
      </div>

      {/* Header */}
      <div className="flex items-center gap-4 mb-8">
        <Link 
          href="/exercises"
          className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
        </Link>
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-lg flex items-center justify-center">
              <Zap className="w-5 h-5 text-white" />
            </div>
            JavaScript 交互练习
          </h1>
          <p className="text-gray-600 mt-2">
            掌握JavaScript核心技术，学习DOM操作、事件处理和现代ES6+特性
          </p>
        </div>
      </div>

      {/* Core Concepts */}
      <div className="card mb-8">
        <div className="card-header">
          <h2 className="text-xl font-semibold">核心概念</h2>
        </div>
        <div className="card-body">
          <div className="grid md:grid-cols-3 gap-6">
            <div>
              <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                <Code className="w-4 h-4 text-yellow-600" />
                语法基础
              </h3>
              <ul className="space-y-2 text-gray-600 text-sm">
                <li>• 变量声明 (let, const, var)</li>
                <li>• 数据类型和类型转换</li>
                <li>• 函数定义和箭头函数</li>
                <li>• 作用域和闭包概念</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                <Zap className="w-4 h-4 text-orange-600" />
                DOM操作
              </h3>
              <ul className="space-y-2 text-gray-600 text-sm">
                <li>• 元素选择和遍历</li>
                <li>• 内容和属性操作</li>
                <li>• 事件监听和处理</li>
                <li>• 动态样式控制</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                <Play className="w-4 h-4 text-red-600" />
                现代特性
              </h3>
              <ul className="space-y-2 text-gray-600 text-sm">
                <li>• Promise和async/await</li>
                <li>• 模板字符串和解构</li>
                <li>• 模块导入导出</li>
                <li>• 数组和对象方法</li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* Learning Path */}
      <div className="card mb-8">
        <div className="card-header">
          <h2 className="text-xl font-semibold">学习路径</h2>
        </div>
        <div className="card-body">
          <div className="grid md:grid-cols-4 gap-6">
            {learningPath.map((phase, index) => (
              <div key={index} className="text-center">
                <div className="w-12 h-12 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-3">
                  <span className="text-white font-bold">{index + 1}</span>
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">{phase.phase}</h3>
                <p className="text-xs text-gray-500 mb-3">{phase.duration}</p>
                <ul className="text-xs text-gray-600 space-y-1">
                  {phase.topics.map((topic, i) => (
                    <li key={i}>{topic}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Exercises */}
      <div className="space-y-8">
        {exercises.map((exercise, index) => (
          <div key={exercise.id} className="card overflow-hidden">
            <div className="md:flex">
              {/* Exercise Preview */}
              <div className="md:w-1/3 bg-gradient-to-br from-yellow-50 to-orange-50 p-6 flex items-center justify-center">
                <div className="text-center">
                  <div className="w-24 h-24 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-xl flex items-center justify-center mx-auto mb-4">
                    <Zap className="w-12 h-12 text-white" />
                  </div>
                  <p className="text-sm text-gray-600">练习 {index + 1}</p>
                  <p className="text-xs text-gray-500 mt-1">{exercise.duration}</p>
                </div>
              </div>

              {/* Exercise Content */}
              <div className="md:w-2/3 p-6">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">
                      {exercise.title}
                    </h3>
                    <p className="text-gray-600 mb-3">
                      {exercise.description}
                    </p>
                  </div>
                  <span className="bg-yellow-100 text-yellow-700 px-3 py-1 rounded-full text-xs font-medium ml-4">
                    {exercise.difficulty}
                  </span>
                </div>

                {/* Skills & Concepts */}
                <div className="grid md:grid-cols-2 gap-4 mb-4">
                  <div>
                    <h4 className="text-sm font-medium text-gray-900 mb-2">技术技能</h4>
                    <div className="flex flex-wrap gap-1">
                      {exercise.skills.map((skill, i) => (
                        <span key={i} className="bg-blue-50 text-blue-700 px-2 py-1 rounded text-xs">
                          {skill}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-gray-900 mb-2">核心概念</h4>
                    <div className="flex flex-wrap gap-1">
                      {exercise.concepts.map((concept, i) => (
                        <span key={i} className="bg-green-50 text-green-700 px-2 py-1 rounded text-xs">
                          {concept}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Features */}
                <div className="mb-6">
                  <h4 className="text-sm font-medium text-gray-900 mb-2">实现功能</h4>
                  <ul className="text-sm text-gray-600 space-y-1">
                    {exercise.features.map((feature, i) => (
                      <li key={i} className="flex items-center gap-2">
                        <div className="w-1 h-1 bg-orange-400 rounded-full"></div>
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Action Buttons */}
                <div className="flex flex-wrap gap-3">
                  <Link
                    href={exercise.demo}
                    className="btn-primary flex items-center gap-2 text-sm"
                  >
                    <Play className="w-4 h-4" />
                    运行演示
                  </Link>
                  <a
                    href={`https://github.com/yourusername/course-portfolio/tree/main/exercises/javascript/${exercise.id}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn-secondary flex items-center gap-2 text-sm"
                  >
                    <Github className="w-4 h-4" />
                    查看源码
                  </a>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* JavaScript Resources */}
      <div className="mt-12 card bg-gradient-to-r from-yellow-50 to-orange-50">
        <div className="card-header">
          <h3 className="text-xl font-semibold">JavaScript 学习资源</h3>
        </div>
        <div className="card-body">
          <div className="grid md:grid-cols-3 gap-6">
            <div>
              <h4 className="font-semibold text-gray-900 mb-3">官方文档</h4>
              <ul className="space-y-2">
                <li>
                  <a href="https://developer.mozilla.org/zh-CN/docs/Web/JavaScript" 
                     target="_blank" 
                     rel="noopener noreferrer"
                     className="text-blue-600 hover:text-blue-800 text-sm flex items-center gap-1">
                    <ExternalLink className="w-3 h-3" />
                    MDN JavaScript 指南
                  </a>
                </li>
                <li>
                  <a href="https://javascript.info/" 
                     target="_blank" 
                     rel="noopener noreferrer"
                     className="text-blue-600 hover:text-blue-800 text-sm flex items-center gap-1">
                    <ExternalLink className="w-3 h-3" />
                    现代JavaScript教程
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-gray-900 mb-3">在线练习</h4>
              <ul className="space-y-2">
                <li>
                  <a href="https://codewars.com/" 
                     target="_blank" 
                     rel="noopener noreferrer"
                     className="text-blue-600 hover:text-blue-800 text-sm flex items-center gap-1">
                    <ExternalLink className="w-3 h-3" />
                    Codewars 算法练习
                  </a>
                </li>
                <li>
                  <a href="https://leetcode.cn/" 
                     target="_blank" 
                     rel="noopener noreferrer"
                     className="text-blue-600 hover:text-blue-800 text-sm flex items-center gap-1">
                    <ExternalLink className="w-3 h-3" />
                    LeetCode 编程题库
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-gray-900 mb-3">工具推荐</h4>
              <ul className="space-y-2">
                <li>
                  <a href="https://code.visualstudio.com/" 
                     target="_blank" 
                     rel="noopener noreferrer"
                     className="text-blue-600 hover:text-blue-800 text-sm flex items-center gap-1">
                    <ExternalLink className="w-3 h-3" />
                    VS Code 编辑器
                  </a>
                </li>
                <li>
                  <a href="https://chrome.google.com/webstore/detail/react-developer-tools/" 
                     target="_blank" 
                     rel="noopener noreferrer"
                     className="text-blue-600 hover:text-blue-800 text-sm flex items-center gap-1">
                    <ExternalLink className="w-3 h-3" />
                    Chrome 开发者工具
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* Next Steps */}
      <div className="mt-8 card bg-gradient-to-r from-yellow-50 to-orange-50">
        <div className="card-body text-center">
          <h3 className="text-xl font-semibold text-gray-900 mb-4">下一步学习</h3>
          <p className="text-gray-600 mb-6">
            掌握JavaScript基础后，可以学习React框架，构建更复杂的用户界面
          </p>
          <Link href="/exercises/react" className="btn-primary">
            React 组件化练习 →
          </Link>
        </div>
      </div>
    </div>
  )
}