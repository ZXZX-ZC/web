'use client'

import { useState } from 'react'
import Link from 'next/link'
import { ArrowLeft, Heart, Star, ThumbsUp, MessageCircle, Share2 } from 'lucide-react'

// 用户卡片组件
function UserCard({ user, onFollow }) {
  return (
    <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
      <div className="flex items-center gap-4 mb-4">
        <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center text-white font-bold text-xl">
          {user.name[0]}
        </div>
        <div>
          <h3 className="font-semibold text-gray-900">{user.name}</h3>
          <p className="text-gray-600 text-sm">@{user.username}</p>
          <p className="text-gray-500 text-sm">{user.role}</p>
        </div>
      </div>
      
      <p className="text-gray-700 mb-4">{user.bio}</p>
      
      <div className="flex justify-between items-center">
        <div className="flex gap-4 text-sm text-gray-500">
          <span>{user.followers} 关注者</span>
          <span>{user.following} 关注中</span>
        </div>
        <button
          onClick={() => onFollow(user.id)}
          className={`px-4 py-2 rounded-lg font-medium transition-colors ${
            user.isFollowing
              ? 'bg-gray-200 text-gray-700 hover:bg-gray-300'
              : 'bg-blue-600 text-white hover:bg-blue-700'
          }`}
        >
          {user.isFollowing ? '已关注' : '关注'}
        </button>
      </div>
    </div>
  )
}

// 帖子组件
function PostCard({ post, onLike, onComment }) {
  return (
    <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-10 h-10 bg-gradient-to-r from-green-500 to-blue-500 rounded-full flex items-center justify-center text-white font-bold">
          {post.author[0]}
        </div>
        <div>
          <h4 className="font-semibold text-gray-900">{post.author}</h4>
          <p className="text-gray-500 text-sm">{post.time}</p>
        </div>
      </div>
      
      <h3 className="font-semibold text-gray-900 mb-2">{post.title}</h3>
      <p className="text-gray-700 mb-4">{post.content}</p>
      
      {post.tags && (
        <div className="flex flex-wrap gap-2 mb-4">
          {post.tags.map((tag, index) => (
            <span
              key={index}
              className="bg-blue-100 text-blue-700 px-2 py-1 rounded-full text-xs"
            >
              #{tag}
            </span>
          ))}
        </div>
      )}
      
      <div className="flex items-center gap-6 text-gray-500">
        <button
          onClick={() => onLike(post.id)}
          className={`flex items-center gap-2 hover:text-red-500 transition-colors ${
            post.isLiked ? 'text-red-500' : ''
          }`}
        >
          <Heart className={`w-4 h-4 ${post.isLiked ? 'fill-current' : ''}`} />
          <span>{post.likes}</span>
        </button>
        
        <button
          onClick={() => onComment(post.id)}
          className="flex items-center gap-2 hover:text-blue-500 transition-colors"
        >
          <MessageCircle className="w-4 h-4" />
          <span>{post.comments}</span>
        </button>
        
        <button className="flex items-center gap-2 hover:text-green-500 transition-colors">
          <Share2 className="w-4 h-4" />
          <span>分享</span>
        </button>
      </div>
    </div>
  )
}

// 统计卡片组件
function StatCard({ icon: Icon, title, value, color }) {
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center gap-4">
        <div className={`w-12 h-12 ${color} rounded-lg flex items-center justify-center`}>
          <Icon className="w-6 h-6 text-white" />
        </div>
        <div>
          <h3 className="font-semibold text-gray-900">{title}</h3>
          <p className="text-2xl font-bold text-gray-800">{value}</p>
        </div>
      </div>
    </div>
  )
}

export default function ComponentsDemo() {
  const [users, setUsers] = useState([
    {
      id: 1,
      name: '李四',
      username: 'lisi',
      role: 'UI/UX 设计师',
      bio: '专注于用户体验设计，喜欢创造美观而实用的界面。',
      followers: 1234,
      following: 567,
      isFollowing: false
    },
    {
      id: 2,
      name: '王五',
      username: 'wangwu',
      role: '全栈开发者',
      bio: '热爱编程，擅长前后端开发，目前专注于React和Node.js。',
      followers: 2345,
      following: 890,
      isFollowing: true
    },
    {
      id: 3,
      name: '赵六',
      username: 'zhaoliu',
      role: '产品经理',
      bio: '关注用户需求，致力于打造有价值的产品体验。',
      followers: 3456,
      following: 123,
      isFollowing: false
    }
  ])

  const [posts, setPosts] = useState([
    {
      id: 1,
      author: '张三',
      time: '2小时前',
      title: 'React组件设计最佳实践',
      content: '在React开发中，组件的设计非常重要。一个好的组件应该具有单一职责、可复用性和良好的API设计。',
      tags: ['React', '前端开发', '最佳实践'],
      likes: 42,
      comments: 8,
      isLiked: false
    },
    {
      id: 2,
      author: '李四',
      time: '4小时前',
      title: 'CSS Grid vs Flexbox 选择指南',
      content: 'Grid和Flexbox都是强大的布局工具，但它们适用于不同的场景。Grid更适合二维布局，Flexbox适合一维布局。',
      tags: ['CSS', '布局', 'Grid', 'Flexbox'],
      likes: 38,
      comments: 12,
      isLiked: true
    },
    {
      id: 3,
      author: '王五',
      time: '1天前',
      title: 'JavaScript异步编程进阶',
      content: '从回调函数到Promise，再到async/await，JavaScript的异步编程不断进化，让我们的代码更加优雅。',
      tags: ['JavaScript', '异步编程', 'Promise'],
      likes: 67,
      comments: 15,
      isLiked: false
    }
  ])

  // 关注/取消关注用户
  const handleFollow = (userId) => {
    setUsers(users.map(user => 
      user.id === userId 
        ? { 
            ...user, 
            isFollowing: !user.isFollowing,
            followers: user.isFollowing ? user.followers - 1 : user.followers + 1
          }
        : user
    ))
  }

  // 点赞帖子
  const handleLike = (postId) => {
    setPosts(posts.map(post =>
      post.id === postId
        ? {
            ...post,
            isLiked: !post.isLiked,
            likes: post.isLiked ? post.likes - 1 : post.likes + 1
          }
        : post
    ))
  }

  // 评论帖子
  const handleComment = (postId) => {
    const comment = prompt('请输入您的评论:')
    if (comment && comment.trim()) {
      setPosts(posts.map(post =>
        post.id === postId
          ? { ...post, comments: post.comments + 1 }
          : post
      ))
    }
  }

  const totalLikes = posts.reduce((sum, post) => sum + post.likes, 0)
  const totalComments = posts.reduce((sum, post) => sum + post.comments, 0)
  const followingCount = users.filter(user => user.isFollowing).length

  return (
    <div className="max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex items-center gap-4 mb-8">
        <Link 
          href="/exercises/react"
          className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
        </Link>
        <div>
          <h1 className="text-3xl font-bold text-gray-900">React 组件基础</h1>
          <p className="text-gray-600 mt-1">
            学习组件设计、Props传递、事件处理和状态管理
          </p>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <StatCard
          icon={Heart}
          title="总点赞数"
          value={totalLikes}
          color="bg-red-500"
        />
        <StatCard
          icon={MessageCircle}
          title="总评论数"
          value={totalComments}
          color="bg-blue-500"
        />
        <StatCard
          icon={ThumbsUp}
          title="关注中"
          value={followingCount}
          color="bg-green-500"
        />
        <StatCard
          icon={Star}
          title="组件数"
          value="4"
          color="bg-purple-500"
        />
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-8">
          {/* User Cards Section */}
          <section>
            <h2 className="text-xl font-semibold text-gray-900 mb-4">推荐用户</h2>
            <div className="grid gap-6">
              {users.map(user => (
                <UserCard
                  key={user.id}
                  user={user}
                  onFollow={handleFollow}
                />
              ))}
            </div>
          </section>

          {/* Posts Section */}
          <section>
            <h2 className="text-xl font-semibold text-gray-900 mb-4">热门帖子</h2>
            <div className="space-y-6">
              {posts.map(post => (
                <PostCard
                  key={post.id}
                  post={post}
                  onLike={handleLike}
                  onComment={handleComment}
                />
              ))}
            </div>
          </section>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Component Info */}
          <div className="card">
            <div className="card-header">
              <h3 className="font-semibold">组件设计原则</h3>
            </div>
            <div className="card-body">
              <div className="space-y-4 text-sm">
                <div>
                  <h4 className="font-medium text-gray-900 mb-1">单一职责</h4>
                  <p className="text-gray-600">每个组件只负责一个功能</p>
                </div>
                <div>
                  <h4 className="font-medium text-gray-900 mb-1">Props传递</h4>
                  <p className="text-gray-600">通过props向子组件传递数据</p>
                </div>
                <div>
                  <h4 className="font-medium text-gray-900 mb-1">事件处理</h4>
                  <p className="text-gray-600">通过回调函数处理用户交互</p>
                </div>
                <div>
                  <h4 className="font-medium text-gray-900 mb-1">状态管理</h4>
                  <p className="text-gray-600">使用useState管理组件状态</p>
                </div>
              </div>
            </div>
          </div>

          {/* Component List */}
          <div className="card">
            <div className="card-header">
              <h3 className="font-semibold">使用的组件</h3>
            </div>
            <div className="card-body">
              <ul className="space-y-2 text-sm">
                <li className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                  <span>UserCard - 用户信息卡片</span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span>PostCard - 帖子展示卡片</span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                  <span>StatCard - 统计数据卡片</span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                  <span>ComponentsDemo - 主容器组件</span>
                </li>
              </ul>
            </div>
          </div>

          {/* Key Concepts */}
          <div className="card">
            <div className="card-header">
              <h3 className="font-semibold">核心概念</h3>
            </div>
            <div className="card-body">
              <ul className="text-sm text-gray-600 space-y-2">
                <li>• JSX语法和组件定义</li>
                <li>• Props的传递和使用</li>
                <li>• 事件处理和回调函数</li>
                <li>• useState状态管理</li>
                <li>• 条件渲染和列表渲染</li>
                <li>• 组件间的数据流</li>
              </ul>
            </div>
          </div>

          {/* Interactive Demo */}
          <div className="card bg-gradient-to-r from-blue-50 to-purple-50">
            <div className="card-body text-center">
              <h3 className="font-semibold text-gray-900 mb-2">交互体验</h3>
              <p className="text-sm text-gray-600 mb-4">
                尝试点击关注按钮、点赞和评论，观察状态的变化
              </p>
              <div className="text-xs text-gray-500">
                所有交互都通过React状态管理实现
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}