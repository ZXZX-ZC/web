import Link from 'next/link'
import { ArrowLeft, ExternalLink, Github, Play, Code, Palette } from 'lucide-react'

export const metadata = {
  title: 'HTML & CSS 基础练习 - Course Portfolio',
  description: '展示HTML和CSS基础练习，包括语义化标记、响应式布局、CSS动画等核心技能',
}

const exercises = [
  {
    id: 'exercise1',
    title: '个人简历页面',
    description: '使用HTML5语义化标签构建个人简历页面，运用CSS进行样式美化',
    difficulty: '初级',
    duration: '2小时',
    skills: ['HTML5语义化', 'CSS基础样式', '盒模型', '文本排版'],
    features: [
      '使用header、main、section等语义化标签',
      '实现响应式字体和间距',
      '添加CSS渐变和阴影效果',
      '优化打印样式'
    ],
    preview: '/screenshots/html-css-exercise1.png',
    github: 'https://github.com/yourusername/course-portfolio/tree/main/exercises/html-css/exercise1',
    demo: '/exercises/html-css/exercise1'
  },
  {
    id: 'exercise2', 
    title: '响应式导航栏',
    description: '构建现代化的响应式导航栏，支持移动端折叠菜单和平滑动画',
    difficulty: '中级',
    duration: '3小时',
    skills: ['响应式设计', 'CSS动画', 'Media Query', 'Flexbox'],
    features: [
      '移动端汉堡菜单设计',
      'CSS-only下拉菜单实现',
      '平滑的hover动画效果',
      '支持键盘导航无障碍访问'
    ],
    preview: '/screenshots/html-css-exercise2.png',
    github: 'https://github.com/yourusername/course-portfolio/tree/main/exercises/html-css/exercise2',
    demo: '/exercises/html-css/exercise2'
  },
  {
    id: 'exercise3',
    title: 'CSS Grid 布局系统',
    description: '掌握CSS Grid布局技术，创建复杂的网格系统和卡片布局',
    difficulty: '中级',
    duration: '4小时', 
    skills: ['CSS Grid', '布局设计', '响应式网格', '对齐控制'],
    features: [
      '创建响应式网格布局',
      '实现不规则卡片排列',
      '掌握grid-template-areas语法',
      '结合Grid和Flexbox布局'
    ],
    preview: '/screenshots/html-css-exercise3.png',
    github: 'https://github.com/yourusername/course-portfolio/tree/main/exercises/html-css/exercise3',
    demo: '/exercises/html-css/exercise3'
  }
]

export default function HtmlCssPage() {
  return (
    <div className="max-w-6xl mx-auto">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-sm text-gray-600 mb-6">
        <Link href="/exercises" className="hover:text-primary-600">
          课程练习
        </Link>
        <span>/</span>
        <span className="text-gray-900">HTML & CSS 基础</span>
      </div>

      {/* Header */}
      <div className="flex items-center gap-4 mb-8">
        <Link 
          href="/exercises"
          className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
        </Link>
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-r from-orange-500 to-red-500 rounded-lg flex items-center justify-center">
              <Palette className="w-5 h-5 text-white" />
            </div>
            HTML & CSS 基础练习
          </h1>
          <p className="text-gray-600 mt-2">
            掌握网页结构与样式设计基础，学习语义化HTML和现代CSS特性
          </p>
        </div>
      </div>

      {/* Learning Objectives */}
      <div className="card mb-8">
        <div className="card-header">
          <h2 className="text-xl font-semibold">学习目标</h2>
        </div>
        <div className="card-body">
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-semibold text-gray-900 mb-3">HTML 技能</h3>
              <ul className="space-y-2 text-gray-600">
                <li className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                  掌握HTML5语义化标签的使用
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                  理解文档结构和层次关系
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                  学习表单元素和数据属性
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                  实践无障碍访问最佳实践
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold text-gray-900 mb-3">CSS 技能</h3>
              <ul className="space-y-2 text-gray-600">
                <li className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                  掌握选择器和层叠规则
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                  学习Flexbox和Grid布局
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                  实现响应式设计和媒体查询
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                  掌握CSS动画和过渡效果
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* Exercises */}
      <div className="space-y-8">
        {exercises.map((exercise, index) => (
          <div key={exercise.id} className="card overflow-hidden">
            <div className="md:flex">
              {/* Exercise Preview */}
              <div className="md:w-1/3 bg-gray-100 p-6 flex items-center justify-center">
                <div className="text-center">
                  <div className="w-24 h-24 bg-gradient-to-r from-orange-500 to-red-500 rounded-xl flex items-center justify-center mx-auto mb-4">
                    <Code className="w-12 h-12 text-white" />
                  </div>
                  <p className="text-sm text-gray-600">练习 {index + 1}</p>
                </div>
              </div>

              {/* Exercise Content */}
              <div className="md:w-2/3 p-6">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">
                      {exercise.title}
                    </h3>
                    <p className="text-gray-600 mb-3">
                      {exercise.description}
                    </p>
                  </div>
                  <div className="flex gap-2 ml-4">
                    <span className="bg-orange-100 text-orange-700 px-2 py-1 rounded text-xs font-medium">
                      {exercise.difficulty}
                    </span>
                    <span className="bg-gray-100 text-gray-700 px-2 py-1 rounded text-xs font-medium">
                      {exercise.duration}
                    </span>
                  </div>
                </div>

                {/* Skills */}
                <div className="mb-4">
                  <h4 className="text-sm font-medium text-gray-900 mb-2">核心技能</h4>
                  <div className="flex flex-wrap gap-1">
                    {exercise.skills.map((skill, i) => (
                      <span key={i} className="bg-blue-50 text-blue-700 px-2 py-1 rounded text-xs">
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Features */}
                <div className="mb-6">
                  <h4 className="text-sm font-medium text-gray-900 mb-2">主要特性</h4>
                  <ul className="text-sm text-gray-600 space-y-1">
                    {exercise.features.map((feature, i) => (
                      <li key={i} className="flex items-center gap-2">
                        <div className="w-1 h-1 bg-gray-400 rounded-full"></div>
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Action Buttons */}
                <div className="flex flex-wrap gap-3">
                  <Link
                    href={exercise.demo}
                    className="btn-primary flex items-center gap-2 text-sm"
                  >
                    <Play className="w-4 h-4" />
                    查看演示
                  </Link>
                  <a
                    href={exercise.github}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn-secondary flex items-center gap-2 text-sm"
                  >
                    <Github className="w-4 h-4" />
                    源码
                  </a>
                  <a
                    href={exercise.preview}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-gray-600 hover:text-gray-800 flex items-center gap-2 text-sm"
                  >
                    <ExternalLink className="w-4 h-4" />
                    预览图
                  </a>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Next Steps */}
      <div className="mt-12 card bg-gradient-to-r from-orange-50 to-red-50">
        <div className="card-body text-center">
          <h3 className="text-xl font-semibold text-gray-900 mb-4">下一步学习</h3>
          <p className="text-gray-600 mb-6">
            完成HTML和CSS基础练习后，可以继续学习JavaScript，为网页添加交互功能
          </p>
          <Link href="/exercises/javascript" className="btn-primary">
            JavaScript 交互练习 →
          </Link>
        </div>
      </div>
    </div>
  )
}