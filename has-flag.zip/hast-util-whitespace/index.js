export {whitespace} from './lib/index.js'
