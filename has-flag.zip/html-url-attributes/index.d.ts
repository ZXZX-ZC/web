export { urlAttributes } from "./lib/index.js";
//# sourceMappingURL=index.d.ts.map