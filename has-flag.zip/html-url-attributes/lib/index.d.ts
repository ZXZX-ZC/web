/**
 * HTML URL properties.
 *
 * Each key is a property name and each value is a list of tag names it applies
 * to or `null` if it applies to all elements.
 *
 * @type {Record<string, Array<string> | null>}
 */
export const urlAttributes: Record<string, Array<string> | null>;
//# sourceMappingURL=index.d.ts.map