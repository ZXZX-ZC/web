// Note: types exposed from `index.d.ts`.
export {toJsxRuntime} from './lib/index.js'
