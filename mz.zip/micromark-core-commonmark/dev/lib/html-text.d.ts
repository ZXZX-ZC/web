/** @type {Construct} */
export const htmlText: Construct;
import type { Construct } from 'micromark-util-types';
//# sourceMappingURL=html-text.d.ts.map