/** @type {Construct} */
export const list: Construct;
import type { Construct } from 'micromark-util-types';
//# sourceMappingURL=list.d.ts.map