/** @type {Construct} */
export const characterReference: Construct;
import type { Construct } from 'micromark-util-types';
//# sourceMappingURL=character-reference.d.ts.map