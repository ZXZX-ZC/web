/** @type {Construct} */
export const labelEnd: Construct;
import type { Construct } from 'micromark-util-types';
//# sourceMappingURL=label-end.d.ts.map