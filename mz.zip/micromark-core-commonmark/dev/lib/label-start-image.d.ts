/** @type {Construct} */
export const labelStartImage: Construct;
import type { Construct } from 'micromark-util-types';
//# sourceMappingURL=label-start-image.d.ts.map