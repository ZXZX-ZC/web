/** @type {Construct} */
export const setextUnderline: Construct;
import type { Construct } from 'micromark-util-types';
//# sourceMappingURL=setext-underline.d.ts.map