/** @type {Construct} */
export const attention: Construct;
import type { Construct } from 'micromark-util-types';
//# sourceMappingURL=attention.d.ts.map