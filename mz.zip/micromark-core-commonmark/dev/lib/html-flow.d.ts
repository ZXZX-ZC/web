/** @type {Construct} */
export const htmlFlow: Construct;
import type { Construct } from 'micromark-util-types';
//# sourceMappingURL=html-flow.d.ts.map