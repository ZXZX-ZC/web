/**
 * @param {Array<Event>} events
 *   Events.
 * @returns {Array<Event>}
 *   Events.
 */
export function postprocess(events: Array<Event>): Array<Event>;
import type { Event } from 'micromark-util-types';
//# sourceMappingURL=postprocess.d.ts.map