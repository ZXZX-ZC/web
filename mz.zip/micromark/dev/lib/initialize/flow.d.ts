/** @type {InitialConstruct} */
export const flow: InitialConstruct;
import type { InitialConstruct } from 'micromark-util-types';
//# sourceMappingURL=flow.d.ts.map