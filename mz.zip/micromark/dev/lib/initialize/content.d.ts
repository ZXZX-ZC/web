/** @type {InitialConstruct} */
export const content: InitialConstruct;
import type { InitialConstruct } from 'micromark-util-types';
//# sourceMappingURL=content.d.ts.map