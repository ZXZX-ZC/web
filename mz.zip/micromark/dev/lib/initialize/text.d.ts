export namespace resolver {
    let resolveAll: Resolver;
}
export const string: InitialConstruct;
export const text: InitialConstruct;
import type { Resolver } from 'micromark-util-types';
import type { InitialConstruct } from 'micromark-util-types';
//# sourceMappingURL=text.d.ts.map